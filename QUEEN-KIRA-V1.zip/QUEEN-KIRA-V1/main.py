import os
import asyncio
import logging
from pyrogram import Client, filters, idle
from pyrogram.types import Message
from pyrogram.enums import ParseMode
from config import Config
from utils.helpers import helpers
from utils.database import db
import importlib
import glob

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TSQKUserBot(Client):
    def __init__(self):
        name = self.__class__.__name__.lower()
        super().__init__(
            name,
            api_id=Config.API_ID,
            api_hash=Config.API_HASH,
            phone_number=Config.PHONE_NUMBER,
            workers=16,
            plugins=dict(root="modules"),
            workdir="sessions"
        )
    
    async def start(self):
        await super().start()
        me = await self.get_me()
        
        logger.info(f"✅ UserBot Started: {me.first_name} (@{me.username})")
        logger.info(f"📦 Version: {Config.BOT_VERSION}")
        logger.info(f"👤 Owner: {Config.BOT_OWNER}")
        logger.info(f"📊 Modules: Loading...")
        
        # Load all modules
        modules_count = len(glob.glob("modules/*.py")) - 1  # exclude __init__.py
        logger.info(f"✅ Loaded {modules_count} modules with 500+ commands")
        
        # Send startup message to log channel
        if Config.LOG_CHANNEL:
            await self.send_message(
                Config.LOG_CHANNEL,
                f"**🚀 Thomas Samuel Queen Kira UserBot Started!**\n\n"
                f"**Version:** `{Config.BOT_VERSION}`\n"
                f"**User:** {me.mention}\n"
                f"**Modules:** `{modules_count}`\n"
                f"**Commands:** `500+`\n"
                f"**Time:** `{helpers.get_readable_time(int((await self.get_me()).id))}`"
            )
    
    async def stop(self):
        logger.info("🛑 Stopping UserBot...")
        if Config.LOG_CHANNEL:
            await self.send_message(
                Config.LOG_CHANNEL,
                "**🛑 Thomas Samuel Queen Kira UserBot Stopped!**"
            )
        await super().stop()

# Create bot instance
app = TSQKUserBot()

# Handler for new users
@app.on_message(filters.new_chat_members)
async def welcome_new_users(client: Client, message: Message):
    for user in message.new_chat_members:
        if user.is_self:
            await message.reply(
                f"**👋 Hello everyone!**\n"
                f"I'm **Thomas Samuel Queen Kira UserBot**\n"
                f"Type `.help` to see my commands."
            )
        else:
            db.add_user(user.id, user.first_name, user.last_name, user.username)

# Handler for commands
@app.on_message(filters.command("help", Config.CMD_PREFIX))
async def help_command(client: Client, message: Message):
    help_text = """
**👑 Thomas Samuel Queen Kira UserBot**
**Version:** `1.0.0`
**Commands:** `500+`

**📌 Available Modules:**
├ **Admin** - Group administration
├ **Fun** - Entertainment commands
├ **Utilities** - Useful tools
├ **Info** - Get information
├ **Maths** - Calculations
├ **Text** - Text manipulation
├ **Convert** - Unit conversions
├ **Telegram** - Telegram tools
├ **Anime** - Anime/Manga info
├ **Crypto** - Cryptocurrency
├ **Weather** - Weather updates
├ **Translate** - Language tools
├ **Downloads** - Media downloads
├ **Stickers** - Sticker tools
├ **Games** - Fun games
├ **Quotes** - Inspirational quotes
├ **News** - Latest news
├ **Memes** - Random memes
├ **Voice** - Voice/audio tools
├ **Image** - Image manipulation
├ **URL** - URL shortener
└ **Developer** - Dev tools

**📝 Usage:** `.<command>`
**Example:** `.alive`

**👤 Owner:** @TSQK_Owner
    """
    await message.reply(help_text)

@app.on_message(filters.command("alive", Config.CMD_PREFIX))
async def alive_command(client: Client, message: Message):
    me = await client.get_me()
    text = f"""
**✨ I'm Alive!**

**Bot:** Thomas Samuel Queen Kira
**Version:** {Config.BOT_VERSION}
**User:** {me.mention}
**Commands:** 500+
**Modules:** 23
**Prefix:** {Config.CMD_PREFIX}

**⚡ Powered by Pyrogram**
    """
    await message.reply(text)

@app.on_message(filters.command("ping", Config.CMD_PREFIX))
async def ping_command(client: Client, message: Message):
    start = datetime.now()
    ms = (datetime.now() - start).microseconds / 1000
    await message.reply(f"**🏓 Pong!** `{ms}ms`")

@app.on_message(filters.command("restart", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def restart_command(client: Client, message: Message):
    await message.reply("**🔄 Restarting UserBot...**")
    await client.stop()
    os.execl(sys.executable, sys.executable, "-m", "main")

if __name__ == "__main__":
    try:
        # Create sessions directory if not exists
        os.makedirs("sessions", exist_ok=True)
        os.makedirs("downloads", exist_ok=True)
        
        # Run the bot
        app.run()
    except KeyboardInterrupt:
        logger.info("👋 UserBot Stopped!")
