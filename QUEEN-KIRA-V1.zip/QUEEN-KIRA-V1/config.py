import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    API_ID = int(os.getenv("API_ID", 0))
    API_HASH = os.getenv("API_HASH", "")
    PHONE_NUMBER = os.getenv("PHONE_NUMBER", "")
    SUDO_USERS = [int(x) for x in os.getenv("SUDO_USERS", "").split(",") if x]
    LOG_CHANNEL = int(os.getenv("LOG_CHANNEL", 0))
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///tsqk.db")
    
    # UserBot Info
    BOT_NAME = "Thomas Samuel Queen Kira"
    BOT_VERSION = "1.0.0"
    BOT_OWNER = "@TSQK_Owner"
    
    # Command Prefix
    CMD_PREFIX = "."
    
    # Limits
    MAX_MESSAGE_LENGTH = 4096
    MAX_REPLY_MESSAGES = 100
