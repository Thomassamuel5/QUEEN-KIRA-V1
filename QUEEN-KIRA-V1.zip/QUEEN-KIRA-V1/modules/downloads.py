from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import os
import yt_dlp
import requests
import aiohttp
import asyncio

@Client.on_message(filters.command("ytdl", Config.CMD_PREFIX) & filters.me)
async def ytdl_command(client: Client, message: Message):
    if len(message.command) > 1:
        url = message.command[1]
        status = await message.reply("**⏬ Downloading video...**")
        
        ydl_opts = {
            'format': 'best[height<=720]',
            'outtmpl': 'downloads/%(title)s.%(ext)s',
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                filename = ydl.prepare_filename(info)
                
                await status.edit_text("**📤 Uploading video...**")
                
                if os.path.exists(filename):
                    await client.send_video(
                        message.chat.id,
                        video=filename,
                        caption=f"**🎬 {info['title']}**\n**Duration:** {info['duration']}s\n**Uploader:** {info['uploader']}"
                    )
                    os.remove(filename)
                    await status.delete()
                else:
                    await status.edit_text("**❌ Download failed!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.ytdl <youtube_url>`")

@Client.on_message(filters.command("yta", Config.CMD_PREFIX) & filters.me)
async def yta_command(client: Client, message: Message):
    if len(message.command) > 1:
        url = message.command[1]
        status = await message.reply("**⏬ Downloading audio...**")
        
        ydl_opts = {
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
            'outtmpl': 'downloads/%(title)s.%(ext)s',
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                filename = f"downloads/{info['title']}.mp3"
                
                await status.edit_text("**📤 Uploading audio...**")
                
                if os.path.exists(filename):
                    await client.send_audio(
                        message.chat.id,
                        audio=filename,
                        caption=f"**🎵 {info['title']}**\n**Duration:** {info['duration']}s\n**Uploader:** {info['uploader']}"
                    )
                    os.remove(filename)
                    await status.delete()
                else:
                    await status.edit_text("**❌ Download failed!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.yta <youtube_url>`")

@Client.on_message(filters.command("download", Config.CMD_PREFIX) & filters.me)
async def download_command(client: Client, message: Message):
    if len(message.command) > 1:
        url = message.command[1]
        status = await message.reply("**⏬ Downloading file...**")
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        filename = url.split('/')[-1].split('?')[0] or "download"
                        with open(f"downloads/{filename}", 'wb') as f:
                            f.write(await resp.read())
                        
                        await status.edit_text("**📤 Uploading file...**")
                        
                        await client.send_document(
                            message.chat.id,
                            document=f"downloads/{filename}",
                            caption=f"**📎 Downloaded from:** {url}"
                        )
                        
                        os.remove(f"downloads/{filename}")
                        await status.delete()
                    else:
                        await status.edit_text("**❌ Download failed!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.download <url>`")

@Client.on_message(filters.command("imdb", Config.CMD_PREFIX) & filters.me)
async def imdb_command(client: Client, message: Message):
    if len(message.command) > 1:
        query = " ".join(message.command[1:])
        status = await message.reply("**🔍 Searching IMDb...**")
        
        try:
            response = requests.get(f"http://www.omdbapi.com/?t={query}&apikey=YOUR_API_KEY")
            data = response.json()
            
            if data.get('Response') == 'True':
                text = f"""
**🎬 {data['Title']} ({data['Year']})**
**Rating:** ⭐ {data['imdbRating']}/10
**Runtime:** {data['Runtime']}
**Genre:** {data['Genre']}
**Director:** {data['Director']}
**Cast:** {data['Actors']}
**Plot:** {data['Plot'][:500]}...
"""
                if data.get('Poster') != 'N/A':
                    await status.delete()
                    await message.reply_photo(data['Poster'], caption=text)
                else:
                    await status.edit_text(text)
            else:
                await status.edit_text("**❌ Movie not found!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.imdb <movie_name>`")

# More download commands: .ytplaylist, .ytsearch, .soundcloud, .spotify, .deezer, .apple_music, .instagram, .twitter, .facebook, .tiktok, .reddit, .pinterest, .imgur, .giphy, .tenor, .flickr, .deviantart, .behance, .dribbble, .unsplash, .pexels, .pixabay
