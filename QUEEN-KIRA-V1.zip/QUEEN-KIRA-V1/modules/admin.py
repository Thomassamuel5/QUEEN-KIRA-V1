from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.enums import ChatMemberStatus, ChatType
from config import Config
import asyncio

# Admin commands (requires admin in groups)
@Client.on_message(filters.command("ban", Config.CMD_PREFIX) & filters.me)
async def ban_user(client: Client, message: Message):
    if message.chat.type == ChatType.PRIVATE:
        await message.reply("❌ This command only works in groups!")
        return
    
    # Check if user is admin
    member = await client.get_chat_member(message.chat.id, message.from_user.id)
    if member.status not in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]:
        await message.reply("❌ You need to be an admin to use this command!")
        return
    
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        reason = " ".join(message.command[1:]) if len(message.command) > 1 else "No reason"
        
        try:
            await client.ban_chat_member(message.chat.id, user_id)
            await message.reply(f"**✅ Banned User!**\n**Reason:** {reason}")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("Reply to a user's message to ban them!")

@Client.on_message(filters.command("unban", Config.CMD_PREFIX) & filters.me)
async def unban_user(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            user_id = int(message.command[1])
            await client.unban_chat_member(message.chat.id, user_id)
            await message.reply(f"**✅ Unbanned User:** `{user_id}`")
        except:
            await message.reply("**❌ Invalid user ID!**")
    else:
        await message.reply("**Usage:** `.unban <user_id>`")

@Client.on_message(filters.command("kick", Config.CMD_PREFIX) & filters.me)
async def kick_user(client: Client, message: Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await client.ban_chat_member(message.chat.id, user_id)
        await asyncio.sleep(1)
        await client.unban_chat_member(message.chat.id, user_id)
        await message.reply(f"**👢 Kicked User!**")
    else:
        await message.reply("Reply to a user's message to kick them!")

@Client.on_message(filters.command("mute", Config.CMD_PREFIX) & filters.me)
async def mute_user(client: Client, message: Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await client.restrict_chat_member(message.chat.id, user_id, permissions=None)
        await message.reply(f"**🔇 Muted User!**")
    else:
        await message.reply("Reply to a user's message to mute them!")

@Client.on_message(filters.command("unmute", Config.CMD_PREFIX) & filters.me)
async def unmute_user(client: Client, message: Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await client.restrict_chat_member(
            message.chat.id, 
            user_id,
            permissions=ChatMemberPermissions(can_send_messages=True)
        )
        await message.reply(f"**🔊 Unmuted User!**")
    else:
        await message.reply("Reply to a user's message to unmute them!")

@Client.on_message(filters.command("pin", Config.CMD_PREFIX) & filters.me)
async def pin_message(client: Client, message: Message):
    if message.reply_to_message:
        await client.pin_chat_message(message.chat.id, message.reply_to_message.id)
        await message.reply("**📌 Message Pinned!**")
    else:
        await message.reply("Reply to a message to pin it!")

@Client.on_message(filters.command("unpin", Config.CMD_PREFIX) & filters.me)
async def unpin_message(client: Client, message: Message):
    if message.reply_to_message:
        await client.unpin_chat_message(message.chat.id, message.reply_to_message.id)
        await message.reply("**📌 Message Unpinned!**")
    else:
        await message.reply("Reply to a message to unpin it!")

@Client.on_message(filters.command("purge", Config.CMD_PREFIX) & filters.me)
async def purge_messages(client: Client, message: Message):
    if message.reply_to_message:
        start_id = message.reply_to_message.id
        end_id = message.id
        await client.delete_messages(message.chat.id, range(start_id, end_id))
        await message.reply(f"**🧹 Purged {end_id - start_id} messages!**")
    else:
        await message.reply("Reply to the first message to purge!")

@Client.on_message(filters.command("promote", Config.CMD_PREFIX) & filters.me)
async def promote_user(client: Client, message: Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await client.promote_chat_member(
            message.chat.id,
            user_id,
            can_change_info=True,
            can_delete_messages=True,
            can_invite_users=True,
            can_restrict_members=True,
            can_pin_messages=True
        )
        await message.reply(f"**⬆️ User Promoted!**")
    else:
        await message.reply("Reply to a user to promote them!")

@Client.on_message(filters.command("demote", Config.CMD_PREFIX) & filters.me)
async def demote_user(client: Client, message: Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await client.promote_chat_member(
            message.chat.id,
            user_id,
            can_change_info=False,
            can_delete_messages=False,
            can_invite_users=False,
            can_restrict_members=False,
            can_pin_messages=False
        )
        await message.reply(f"**⬇️ User Demoted!**")
    else:
        await message.reply("Reply to a user to demote them!")

# More admin commands...
# .settitle, .setphoto, .setdescription, .setusername, .invite, .admins, .bots, .all, .zombies, .del, .edit, .copy, .export, .import, .lock, .unlock, .slowmode, .antispam, .warn, .warns, .resetwarns, etc.
