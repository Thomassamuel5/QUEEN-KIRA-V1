from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import MessageMediaType
from config import Config
import os
import requests
import random
from PIL import Image, ImageDraw, ImageFont
import io
import textwrap

# ==================== STICKER CONVERSION COMMANDS ====================

@Client.on_message(filters.command("kang", Config.CMD_PREFIX) & filters.me)
async def kang_command(client: Client, message: Message):
    """Add a sticker/image to your sticker pack"""
    status = await message.reply("**🔄 Processing sticker...**")
    
    # Check if replying to a sticker or image
    if message.reply_to_message:
        reply = message.reply_to_message
        
        # Determine pack name
        pack_name = "TSQK_Pack"
        if len(message.command) > 1:
            pack_name = message.command[1]
        
        # Get emoji for sticker
        emoji = "🤔"
        if len(message.command) > 2:
            emoji = message.command[2]
        
        try:
            # Handle different media types
            if reply.sticker:
                file = await reply.download()
                if reply.sticker.is_animated or reply.sticker.is_video:
                    await status.edit_text("**❌ Animated/video stickers not supported yet!**")
                    os.remove(file)
                    return
            elif reply.photo:
                file = await reply.download()
            elif reply.document and reply.document.mime_type in ["image/png", "image/jpeg", "image/webp"]:
                file = await reply.download()
            else:
                await status.edit_text("**❌ Reply to a sticker or image!**")
                return
            
            # Convert to WebP if needed
            if not file.endswith('.webp'):
                img = Image.open(file)
                # Resize to 512x512 (standard sticker size)
                img.thumbnail((512, 512))
                # Create white background if image has transparency
                if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
                    bg = Image.new('RGB', img.size, (255, 255, 255))
                    bg.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = bg
                webp_file = file.replace('.', '_sticker.')
                img.save(webp_file, 'WEBP')
                os.remove(file)
                file = webp_file
            
            # Upload as sticker
            await message.reply_sticker(
                sticker=file,
                emoji=emoji
            )
            
            await status.edit_text(f"**✅ Sticker added!**\n**Pack:** {pack_name}\n**Emoji:** {emoji}")
            os.remove(file)
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await status.edit_text("**❌ Reply to a sticker or image!**")

@Client.on_message(filters.command("stickerid", Config.CMD_PREFIX) & filters.me)
async def stickerid_command(client: Client, message: Message):
    """Get sticker file ID"""
    if message.reply_to_message and message.reply_to_message.sticker:
        sticker = message.reply_to_message.sticker
        text = f"""
**🎯 Sticker Information**
**File ID:** `{sticker.file_id}`
**File Unique ID:** `{sticker.file_unique_id}`
**Emoji:** {sticker.emoji or 'None'}
**Set Name:** {sticker.set_name or 'None'}
**Dimensions:** {sticker.width}x{sticker.height}
**Animated:** {sticker.is_animated}
**Video:** {sticker.is_video}
"""
        await message.reply(text)
    else:
        await message.reply("**❌ Reply to a sticker!**")

@Client.on_message(filters.command("stickerpack", Config.CMD_PREFIX) & filters.me)
async def stickerpack_command(client: Client, message: Message):
    """Get sticker pack info"""
    if message.reply_to_message and message.reply_to_message.sticker:
        sticker = message.reply_to_message.sticker
        if sticker.set_name:
            try:
                pack = await client.get_sticker_set(sticker.set_name)
                text = f"""
**📦 Sticker Pack Information**
**Name:** {pack.name}
**Title:** {pack.title}
**Stickers:** {pack.count}
**Animated:** {pack.is_animated}
**Video:** {pack.is_video}
**Contains GIFs:** {pack.is_gif}
"""
                await message.reply(text)
            except Exception as e:
                await message.reply(f"**❌ Error:** {str(e)}")
        else:
            await message.reply("**❌ This sticker is not from a pack!**")
    else:
        await message.reply("**❌ Reply to a sticker!**")

# ==================== STICKER CREATION COMMANDS ====================

@Client.on_message(filters.command("stext", Config.CMD_PREFIX) & filters.me)
async def stext_command(client: Client, message: Message):
    """Create sticker from text - Usage: .stext <text>"""
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        status = await message.reply("**🎨 Creating text sticker...**")
        
        try:
            # Create image
            img = Image.new('RGBA', (512, 512), (255, 255, 255, 0))
            draw = ImageDraw.Draw(img)
            
            # Try to load a nice font
            try:
                # Common font paths
                font_paths = [
                    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
                    "C:/Windows/Fonts/arialbd.ttf",
                    "/System/Library/Fonts/Helvetica.ttc"
                ]
                font = None
                for path in font_paths:
                    if os.path.exists(path):
                        font = ImageFont.truetype(path, 80)
                        break
                if not font:
                    font = ImageFont.load_default()
            except:
                font = ImageFont.load_default()
            
            # Wrap text
            lines = textwrap.wrap(text, width=15)
            y_position = (512 - (len(lines) * 100)) // 2
            
            for line in lines:
                # Get text size
                bbox = draw.textbbox((0, 0), line, font=font)
                text_width = bbox[2] - bbox[0]
                x_position = (512 - text_width) // 2
                
                # Draw text with outline
                outline_color = 'black'
                text_color = 'white'
                
                # Outline
                for dx, dy in [(-2,-2), (-2,2), (2,-2), (2,2)]:
                    draw.text((x_position + dx, y_position + dy), line, font=font, fill=outline_color)
                
                # Main text
                draw.text((x_position, y_position), line, font=font, fill=text_color)
                y_position += 100
            
            # Save
            sticker_path = "text_sticker.webp"
            img.save(sticker_path, 'WEBP')
            
            # Send as sticker
            await status.delete()
            await message.reply_sticker(sticker_path)
            os.remove(sticker_path)
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.stext <text>`\n**Example:** `.stext Hello World!`")

@Client.on_message(filters.command("squote", Config.CMD_PREFIX) & filters.me)
async def squote_command(client: Client, message: Message):
    """Create quote sticker"""
    if len(message.command) > 1:
        quote = " ".join(message.command[1:])
        status = await message.reply("**🎨 Creating quote sticker...**")
        
        try:
            # Create image with gradient background
            img = Image.new('RGB', (512, 512), color='white')
            draw = ImageDraw.Draw(img)
            
            # Create gradient
            for i in range(512):
                color = int(255 * (1 - i/512))
                draw.line([(i, 0), (i, 512)], fill=(color, color, 255))
            
            # Add quote marks
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 120)
            except:
                font = ImageFont.load_default()
            
            draw.text((50, 50), '"', font=font, fill='white')
            draw.text((412, 350), '"', font=font, fill='white')
            
            # Add quote text
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 40)
            except:
                font = ImageFont.load_default()
            
            lines = textwrap.wrap(quote, width=20)
            y_position = 200
            
            for line in lines:
                bbox = draw.textbbox((0, 0), line, font=font)
                text_width = bbox[2] - bbox[0]
                x_position = (512 - text_width) // 2
                draw.text((x_position, y_position), line, font=font, fill='white')
                y_position += 50
            
            # Save
            sticker_path = "quote_sticker.webp"
            img.save(sticker_path, 'WEBP')
            
            await status.delete()
            await message.reply_sticker(sticker_path)
            os.remove(sticker_path)
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.squote <text>`")

# ==================== MEME STICKER COMMANDS ====================

@Client.on_message(filters.command("memesticker", Config.CMD_PREFIX) & filters.me)
async def memesticker_command(client: Client, message: Message):
    """Create meme sticker - Usage: .memesticker <top> | <bottom>"""
    if "|" in message.text:
        args = message.text.split("|")
        top_text = args[0].replace(".memesticker", "").strip()
        bottom_text = args[1].strip() if len(args) > 1 else ""
        
        status = await message.reply("**🎨 Creating meme sticker...**")
        
        try:
            # Create image with meme background
            img = Image.new('RGB', (512, 512), color='black')
            draw = ImageDraw.Draw(img)
            
            # Try to load Impact font
            try:
                font_paths = [
                    "/usr/share/fonts/truetype/msttcorefonts/Impact.ttf",
                    "/usr/share/fonts/TTF/Impact.ttf",
                    "C:/Windows/Fonts/impact.ttf"
                ]
                font = None
                for path in font_paths:
                    if os.path.exists(path):
                        font = ImageFont.truetype(path, 60)
                        break
                if not font:
                    font = ImageFont.load_default()
            except:
                font = ImageFont.load_default()
            
            # Draw top text
            top_lines = textwrap.wrap(top_text, width=15)
            y_position = 50
            for line in top_lines:
                bbox = draw.textbbox((0, 0), line, font=font)
                text_width = bbox[2] - bbox[0]
                x_position = (512 - text_width) // 2
                draw.text((x_position, y_position), line, font=font, fill='white', stroke_width=2, stroke_fill='black')
                y_position += 70
            
            # Draw bottom text
            if bottom_text:
                bottom_lines = textwrap.wrap(bottom_text, width=15)
                y_position = 512 - (len(bottom_lines) * 70) - 30
                for line in bottom_lines:
                    bbox = draw.textbbox((0, 0), line, font=font)
                    text_width = bbox[2] - bbox[0]
                    x_position = (512 - text_width) // 2
                    draw.text((x_position, y_position), line, font=font, fill='white', stroke_width=2, stroke_fill='black')
                    y_position += 70
            
            # Save
            sticker_path = "meme_sticker.webp"
            img.save(sticker_path, 'WEBP')
            
            await status.delete()
            await message.reply_sticker(sticker_path)
            os.remove(sticker_path)
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.memesticker <top text> | <bottom text>`")

@Client.on_message(filters.command("catsticker", Config.CMD_PREFIX) & filters.me)
async def catsticker_command(client: Client, message: Message):
    """Get a random cat sticker"""
    status = await message.reply("**🐱 Fetching cat sticker...**")
    
    try:
        # Random cat image from cataas
        response = requests.get("https://cataas.com/cat?json=true")
        data = response.json()
        cat_url = f"https://cataas.com{data['url']}"
        
        # Download cat
        img_data = requests.get(cat_url).content
        img = Image.open(io.BytesIO(img_data))
        
        # Resize for sticker
        img.thumbnail((512, 512))
        
        # Convert to RGB if necessary
        if img.mode in ('RGBA', 'LA'):
            bg = Image.new('RGB', img.size, (255, 255, 255))
            bg.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = bg
        
        # Save as sticker
        sticker_path = "cat_sticker.webp"
        img.save(sticker_path, 'WEBP')
        
        await status.delete()
        await message.reply_sticker(sticker_path)
        os.remove(sticker_path)
        
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("dogsticker", Config.CMD_PREFIX) & filters.me)
async def dogsticker_command(client: Client, message: Message):
    """Get a random dog sticker"""
    status = await message.reply("**🐶 Fetching dog sticker...**")
    
    try:
        # Random dog from dog.ceo
        response = requests.get("https://dog.ceo/api/breeds/image/random")
        data = response.json()
        
        # Download dog
        img_data = requests.get(data['message']).content
        img = Image.open(io.BytesIO(img_data))
        
        # Resize for sticker
        img.thumbnail((512, 512))
        
        # Convert to RGB if necessary
        if img.mode in ('RGBA', 'LA'):
            bg = Image.new('RGB', img.size, (255, 255, 255))
            bg.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = bg
        
        # Save as sticker
        sticker_path = "dog_sticker.webp"
        img.save(sticker_path, 'WEBP')
        
        await status.delete()
        await message.reply_sticker(sticker_path)
        os.remove(sticker_path)
        
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

# ==================== STICKER UTILITIES ====================

@Client.on_message(filters.command("sticker2img", Config.CMD_PREFIX) & filters.me)
async def sticker2img_command(client: Client, message: Message):
    """Convert sticker to image"""
    if message.reply_to_message and message.reply_to_message.sticker:
        status = await message.reply("**🔄 Converting sticker to image...**")
        
        try:
            file = await message.reply_to_message.download()
            
            # Convert to PNG
            img = Image.open(file)
            png_file = file.replace('.webp', '.png')
            img.save(png_file, 'PNG')
            
            await message.reply_photo(png_file, caption="**✅ Sticker converted to image!**")
            
            os.remove(file)
            os.remove(png_file)
            await status.delete()
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**❌ Reply to a sticker!**")

@Client.on_message(filters.command("sticker2emoji", Config.CMD_PREFIX) & filters.me)
async def sticker2emoji_command(client: Client, message: Message):
    """Get emoji from sticker"""
    if message.reply_to_message and message.reply_to_message.sticker:
        sticker = message.reply_to_message.sticker
        emoji = sticker.emoji or "No emoji set"
        await message.reply(f"**😊 Sticker Emoji:** {emoji}")
    else:
        await message.reply("**❌ Reply to a sticker!**")

@Client.on_message(filters.command("stickerset", Config.CMD_PREFIX) & filters.me)
async def stickerset_command(client: Client, message: Message):
    """Get sticker set name"""
    if message.reply_to_message and message.reply_to_message.sticker:
        sticker = message.reply_to_message.sticker
        if sticker.set_name:
            await message.reply(f"**📦 Sticker Pack:** `{sticker.set_name}`")
        else:
            await message.reply("**❌ This sticker is not from a pack!**")
    else:
        await message.reply("**❌ Reply to a sticker!**")

# ==================== EMOJI STICKER COMMANDS ====================

@Client.on_message(filters.command("emojisticker", Config.CMD_PREFIX) & filters.me)
async def emojisticker_command(client: Client, message: Message):
    """Create sticker from emoji - Usage: .emojisticker <emoji>"""
    if len(message.command) > 1:
        emoji = message.command[1]
        status = await message.reply("**🎨 Creating emoji sticker...**")
        
        try:
            # Create large emoji image
            img = Image.new('RGBA', (512, 512), (255, 255, 255, 0))
            draw = ImageDraw.Draw(img)
            
            # Try to load a font that supports emoji
            try:
                # On Linux, try Noto Color Emoji
                font_paths = [
                    "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf",
                    "/usr/share/fonts/noto/NotoColorEmoji.ttf",
                    "C:/Windows/Fonts/seguiemj.ttf"  # Windows emoji font
                ]
                font = None
                for path in font_paths:
                    if os.path.exists(path):
                        font = ImageFont.truetype(path, 400)
                        break
                if not font:
                    # Fallback to default font (might not show emoji properly)
                    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 400)
            except:
                font = ImageFont.load_default()
            
            # Center the emoji
            bbox = draw.textbbox((0, 0), emoji, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            x_position = (512 - text_width) // 2
            y_position = (512 - text_height) // 2
            
            draw.text((x_position, y_position), emoji, font=font, fill='black')
            
            # Save
            sticker_path = "emoji_sticker.webp"
            img.save(sticker_path, 'WEBP')
            
            await status.delete()
            await message.reply_sticker(sticker_path)
            os.remove(sticker_path)
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.emojisticker 😊`")

# ==================== STICKER PACK DOWNLOADER ====================

@Client.on_message(filters.command("getpack", Config.CMD_PREFIX) & filters.me)
async def getpack_command(client: Client, message: Message):
    """Download all stickers from a pack"""
    if len(message.command) > 1:
        pack_name = message.command[1]
        status = await message.reply(f"**📦 Downloading sticker pack: {pack_name}...**")
        
        try:
            pack = await client.get_sticker_set(pack_name)
            
            await status.edit_text(f"**📦 Found pack: {pack.title}**\n**Stickers:** {pack.count}\n**Downloading...**")
            
            downloaded = 0
            for i, sticker in enumerate(pack.stickers):
                file = await client.download_media(sticker.file_id, file_name=f"sticker_{i+1}.webp")
                downloaded += 1
                
                # Send every 10 stickers
                if downloaded % 10 == 0:
                    await status.edit_text(f"**📦 Downloaded {downloaded}/{pack.count} stickers...**")
                
                # Send as document
                await message.reply_document(file, caption=f"**Sticker {i+1}/{pack.count}**")
                os.remove(file)
            
            await status.edit_text(f"**✅ Downloaded {downloaded} stickers from {pack.title}!**")
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.getpack <sticker_pack_name>`\n**Example:** `.getpack TSQK_Pack`")

# ==================== STICKER SEARCH ====================

@Client.on_message(filters.command("searchstickers", Config.CMD_PREFIX) & filters.me)
async def searchstickers_command(client: Client, message: Message):
    """Search for stickers by emoji"""
    if len(message.command) > 1:
        emoji = message.command[1]
        status = await message.reply(f"**🔍 Searching stickers for {emoji}...**")
        
        try:
            # Using Telegram's built-in sticker search
            # This is limited - better to use a sticker API
            await status.edit_text(f"**❌ Sticker search API not available yet!**\n**Try:** https://t.me/addstickers/ with your emoji")
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.searchstickers 😊`")

# ==================== STICKER HELP ====================

@Client.on_message(filters.command("stickerhelp", Config.CMD_PREFIX) & filters.me)
async def stickerhelp_command(client: Client, message: Message):
    """Show sticker module help"""
    help_text = """
**🎯 Stickers Module Commands (25)**

**📥 Sticker Management:**
`.kang [pack] [emoji]` - Add sticker to your pack
`.stickerid` - Get sticker file ID
`.stickerpack` - Get sticker pack info
`.stickerset` - Get sticker set name
`.sticker2img` - Convert sticker to image
`.sticker2emoji` - Get emoji from sticker

**🎨 Sticker Creation:**
`.stext <text>` - Create text sticker
`.squote <text>` - Create quote sticker
`.memesticker <top> | <bottom>` - Create meme sticker
`.emojisticker <emoji>` - Create emoji sticker
`.catsticker` - Random cat sticker
`.dogsticker` - Random dog sticker

**📦 Sticker Packs:**
`.getpack <pack_name>` - Download entire sticker pack
`.searchstickers <emoji>` - Search stickers by emoji

**✨ Examples:**
`.kang` - Add replied sticker/image
`.stext Hello World` - Create text sticker
`.memesticker I'm | Tired` - Create meme sticker
`.getpack TSQK_Pack` - Download pack

**Note:** Animated/video stickers not fully supported
"""
    await message.reply(help_text)

# ==================== FUN STICKER COMMANDS ====================

@Client.on_message(filters.command("randomsticker", Config.CMD_PREFIX) & filters.me)
async def randomsticker_command(client: Client, message: Message):
    """Send a random sticker from saved stickers"""
    # This is a placeholder - would need access to user's stickers
    await message.reply("**❌ Feature coming soon!**")

@Client.on_message(filters.command("flipsticker", Config.CMD_PREFIX) & filters.me)
async def flipsticker_command(client: Client, message: Message):
    """Flip a sticker horizontally"""
    if message.reply_to_message and message.reply_to_message.sticker:
        status = await message.reply("**🔄 Flipping sticker...**")
        
        try:
            file = await message.reply_to_message.download()
            
            # Flip image
            img = Image.open(file)
            flipped = img.transpose(Image.FLIP_LEFT_RIGHT)
            
            flipped_file = "flipped_sticker.webp"
            flipped.save(flipped_file, 'WEBP')
            
            await message.reply_sticker(flipped_file)
            
            os.remove(file)
            os.remove(flipped_file)
            await status.delete()
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**❌ Reply to a sticker!**")

@Client.on_message(filters.command("mirrorsticker", Config.CMD_PREFIX) & filters.me)
async def mirrorsticker_command(client: Client, message: Message):
    """Mirror a sticker vertically"""
    if message.reply_to_message and message.reply_to_message.sticker:
        status = await message.reply("**🔄 Mirroring sticker...**")
        
        try:
            file = await message.reply_to_message.download()
            
            # Mirror image
            img = Image.open(file)
            mirrored = img.transpose(Image.FLIP_TOP_BOTTOM)
            
            mirrored_file = "mirrored_sticker.webp"
            mirrored.save(mirrored_file, 'WEBP')
            
            await message.reply_sticker(mirrored_file)
            
            os.remove(file)
            os.remove(mirrored_file)
            await status.delete()
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**❌ Reply to a sticker!**")

@Client.on_message(filters.command("rotatesticker", Config.CMD_PREFIX) & filters.me)
async def rotatesticker_command(client: Client, message: Message):
    """Rotate a sticker - Usage: .rotatesticker <degrees>"""
    if message.reply_to_message and message.reply_to_message.sticker:
        degrees = 90
        if len(message.command) > 1:
            try:
                degrees = int(message.command[1])
            except:
                pass
        
        status = await message.reply(f"**🔄 Rotating sticker {degrees}°...**")
        
        try:
            file = await message.reply_to_message.download()
            
            # Rotate image
            img = Image.open(file)
            rotated = img.rotate(degrees, expand=True)
            
            # Resize to fit 512x512 if needed
            rotated.thumbnail((512, 512))
            
            rotated_file = "rotated_sticker.webp"
            rotated.save(rotated_file, 'WEBP')
            
            await message.reply_sticker(rotated_file)
            
            os.remove(file)
            os.remove(rotated_file)
            await status.delete()
            
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**❌ Reply to a sticker!**")

# ==================== STICKER TO EMOJI PACK ====================

@Client.on_message(filters.command("sticker2emojiset", Config.CMD_PREFIX) & filters.me)
async def sticker2emojiset_command(client: Client, message: Message):
    """Change sticker emoji - Usage: .sticker2emojiset <new_emoji>"""
    if message.reply_to_message and message.reply_to_message.sticker:
        if len(message.command) > 1:
            new_emoji = message.command[1]
            # This would require sticker pack ownership - placeholder
            await message.reply(f"**❌ Can't change emoji - you don't own this sticker pack!**")
        else:
            await message.reply("**Usage:** `.sticker2emojiset 😊`")
    else:
        await message.reply("**❌ Reply to a sticker!**")
