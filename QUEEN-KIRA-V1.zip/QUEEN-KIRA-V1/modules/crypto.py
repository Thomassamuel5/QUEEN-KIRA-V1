from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import requests
import datetime

@Client.on_message(filters.command("btc", Config.CMD_PREFIX) & filters.me)
async def btc_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,eur,gbp,inr&include_24hr_change=true")
        data = response.json()
        
        btc = data['bitcoin']
        text = f"""
**₿ Bitcoin Price**
**USD:** ${btc['usd']:,.2f} (24h: {btc['usd_24h_change']:.2f}%)
**EUR:** €{btc['eur']:,.2f}
**GBP:** £{btc['gbp']:,.2f}
**INR:** ₹{btc['inr']:,.2f}
🕒 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching Bitcoin price!**")

@Client.on_message(filters.command("eth", Config.CMD_PREFIX) & filters.me)
async def eth_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd,eur,gbp,inr&include_24hr_change=true")
        data = response.json()
        
        eth = data['ethereum']
        text = f"""
**💎 Ethereum Price**
**USD:** ${eth['usd']:,.2f} (24h: {eth['usd_24h_change']:.2f}%)
**EUR:** €{eth['eur']:,.2f}
**GBP:** £{eth['gbp']:,.2f}
**INR:** ₹{eth['inr']:,.2f}
🕒 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching Ethereum price!**")

@Client.on_message(filters.command("crypto", Config.CMD_PREFIX) & filters.me)
async def crypto_command(client: Client, message: Message):
    if len(message.command) > 1:
        coin = message.command[1].lower()
        
        try:
            response = requests.get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin}&vs_currencies=usd,eur,gbp,inr&include_24hr_change=true")
            data = response.json()
            
            if coin in data:
                coin_data = data[coin]
                text = f"""
**🪙 {coin.upper()} Price**
**USD:** ${coin_data['usd']:,.2f} (24h: {coin_data['usd_24h_change']:.2f}%)
**EUR:** €{coin_data['eur']:,.2f}
**GBP:** £{coin_data['gbp']:,.2f}
**INR:** ₹{coin_data['inr']:,.2f}
🕒 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
                await message.reply(text)
            else:
                await message.reply(f"**❌ Cryptocurrency '{coin}' not found!**")
        except:
            await message.reply("**❌ Error fetching crypto price!**")
    else:
        await message.reply("**Usage:** `.crypto <coin_name>`\n**Example:** `.crypto bitcoin`")

@Client.on_message(filters.command("cryptolist", Config.CMD_PREFIX) & filters.me)
async def cryptolist_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1")
        data = response.json()
        
        text = "**📊 Top 10 Cryptocurrencies**\n\n"
        for i, coin in enumerate(data, 1):
            text += f"{i}. {coin['name']} ({coin['symbol'].upper()})\n"
            text += f"   💰 ${coin['current_price']:,.2f}\n"
            text += f"   📈 24h: {coin['price_change_percentage_24h']:.2f}%\n\n"
        
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching crypto list!**")

@Client.on_message(filters.command("gas", Config.CMD_PREFIX) & filters.me)
async def gas_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.etherscan.io/api?module=gastracker&action=gasoracle")
        data = response.json()
        
        if data['status'] == '1':
            gas = data['result']
            text = f"""
**⛽ Ethereum Gas Fees**
**Safe (Slow):** {gas['SafeGasPrice']} Gwei
**Propose (Average):** {gas['ProposeGasPrice']} Gwei
**Fast:** {gas['FastGasPrice']} Gwei
**Base Fee:** {gas['suggestBaseFee']} Gwei
🕒 {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            await message.reply(text)
        else:
            await message.reply("**❌ Error fetching gas fees!**")
    except:
        await message.reply("**❌ Error fetching gas fees!**")

@Client.on_message(filters.command("dominance", Config.CMD_PREFIX) & filters.me)
async def dominance_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.coingecko.com/api/v3/global")
        data = response.json()
        
        btc_dom = data['data']['market_cap_percentage']['btc']
        eth_dom = data['data']['market_cap_percentage']['eth']
        
        text = f"""
**📊 Market Dominance**
**Bitcoin (BTC):** {btc_dom:.2f}%
**Ethereum (ETH):** {eth_dom:.2f}%
**Others:** {100 - btc_dom - eth_dom:.2f}%

**Total Market Cap:** ${data['data']['total_market_cap']['usd'] / 1e12:.2f}T
**24h Volume:** ${data['data']['total_volume']['usd'] / 1e9:.2f}B
"""
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching dominance data!**")

# More crypto commands: .ltc, .xrp, .ada, .dot, .link, .bch, .xlm, .doge, .shib, .matic, .sol, .avax, .atom, .algo, .vet, .theta, .trx, .etc, .eos, .neo, .xtz, .xmr, .dash, .zcash, .waves, .stx, .hbar, .icp, .fil, .apt, .sui, .arb, .op, .imx, .grt, .rndr, .fet, .agix, .ocean, .rose, .near, .flow, .mina, .egld, .kda, .hnt, .iotx, .stmx
