from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import random
import pyjokes
import requests
import asyncio

@Client.on_message(filters.command("joke", Config.CMD_PREFIX) & filters.me)
async def joke_command(client: Client, message: Message):
    jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "What do you call a fake noodle? An impasta!",
        "Why did the scarecrow win an award? Because he was outstanding in his field!",
        "How does a penguin build its house? Igloos it together!",
        "Why don't eggs tell jokes? They'd crack each other up!",
        "What do you call a bear with no teeth? A gummy bear!",
        "Why did the math book look sad? Because it had too many problems!",
        "What's orange and sounds like a parrot? A carrot!",
        "Why don't skeletons fight each other? They don't have the guts!",
        "What do you call a sleeping bull? A bulldozer!"
    ]
    await message.reply(random.choice(jokes))

@Client.on_message(filters.command("pyjoke", Config.CMD_PREFIX) & filters.me)
async def pyjoke_command(client: Client, message: Message):
    await message.reply(pyjokes.get_joke())

@Client.on_message(filters.command("roast", Config.CMD_PREFIX) & filters.me)
async def roast_command(client: Client, message: Message):
    roasts = [
        "You're not stupid; you just have bad luck thinking.",
        "I'd agree with you but then we'd both be wrong.",
        "You bring everyone so much joy! When you leave.",
        "I'd explain it to you but I don't have any crayons with me.",
        "If I wanted to kill myself I'd climb your ego and jump to your IQ.",
        "You're not the dumbest person on earth, but you better hope they don't die.",
        "Somewhere out there is a tree tirelessly producing oxygen for you. You owe it an apology.",
        "You're so ugly, when you looked in the mirror, it reflected on your personality.",
        "If laughter is the best medicine, your face must be curing the world.",
        "I've seen salads more intimidating than you."
    ]
    if message.reply_to_message:
        user = message.reply_to_message.from_user.first_name
        roast = random.choice(roasts)
        await message.reply(f"{user}, {roast}")
    else:
        await message.reply(random.choice(roasts))

@Client.on_message(filters.command("insult", Config.CMD_PREFIX) & filters.me)
async def insult_command(client: Client, message: Message):
    insults = [
        "You're as useless as the 'ueue' in 'queue'.",
        "You're not pretty enough to be this dumb.",
        "Your family tree must be a cactus because everyone on it is a prick.",
        "You're proof that evolution can go in reverse.",
        "You're so dense, light bends around you.",
        "I'd call you a tool, but even tools have a purpose.",
        "You're not a complete idiot, some parts are missing.",
        "You're about as useful as a screen door on a submarine.",
        "I'd tell you to go outside, but the sun doesn't associate with trash.",
        "You're so irrelevant, even your imaginary friends left you."
    ]
    if message.reply_to_message:
        user = message.reply_to_message.from_user.first_name
        insult = random.choice(insults)
        await message.reply(f"{user}, {insult}")
    else:
        await message.reply(random.choice(insults))

@Client.on_message(filters.command("compliment", Config.CMD_PREFIX) & filters.me)
async def compliment_command(client: Client, message: Message):
    compliments = [
        "You're like a ray of sunshine on a cloudy day!",
        "Your smile is contagious.",
        "You're more fun than bubble wrap.",
        "You're one of the strongest people I know.",
        "You're a gift to those around you.",
        "You're so thoughtful and kind.",
        "You have the best laugh.",
        "You're amazing just the way you are.",
        "You light up the room.",
        "You're a true friend."
    ]
    if message.reply_to_message:
        user = message.reply_to_message.from_user.first_name
        compliment = random.choice(compliments)
        await message.reply(f"{user}, {compliment}")
    else:
        await message.reply(random.choice(compliments))

@Client.on_message(filters.command("fact", Config.CMD_PREFIX) & filters.me)
async def fact_command(client: Client, message: Message):
    facts = [
        "Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs, still edible!",
        "A day on Venus is longer than a year on Venus.",
        "Bananas are berries, but strawberries aren't.",
        "Octopuses have three hearts and blue blood.",
        "The Eiffel Tower can be 15 cm taller during summer.",
        "Cows have best friends and get stressed when separated.",
        "The shortest war in history lasted 38 minutes (Anglo-Zanzibar War, 1896).",
        "Wombat poop is cube-shaped.",
        "A group of flamingos is called a 'flamboyance'.",
        "The world's oldest known recipe is for beer."
    ]
    await message.reply(f"**Did you know?**\n{random.choice(facts)}")

@Client.on_message(filters.command("coinflip", Config.CMD_PREFIX) & filters.me)
async def coinflip_command(client: Client, message: Message):
    result = random.choice(["Heads", "Tails"])
    await message.reply(f"**🪙 Coin Flip:** {result}")

@Client.on_message(filters.command("dice", Config.CMD_PREFIX) & filters.me)
async def dice_command(client: Client, message: Message):
    sides = int(message.command[1]) if len(message.command) > 1 else 6
    if sides > 100:
        sides = 100
    result = random.randint(1, sides)
    await message.reply(f"**🎲 Dice ({sides} sides):** {result}")

@Client.on_message(filters.command("rps", Config.CMD_PREFIX) & filters.me)
async def rps_command(client: Client, message: Message):
    choices = ["rock", "paper", "scissors"]
    if len(message.command) > 1 and message.command[1].lower() in choices:
        user_choice = message.command[1].lower()
        bot_choice = random.choice(choices)
        
        if user_choice == bot_choice:
            result = "It's a tie! 🤝"
        elif (user_choice == "rock" and bot_choice == "scissors") or \
             (user_choice == "paper" and bot_choice == "rock") or \
             (user_choice == "scissors" and bot_choice == "paper"):
            result = "You win! 🎉"
        else:
            result = "I win! 🤖"
        
        await message.reply(f"**Rock Paper Scissors**\nYou: {user_choice}\nMe: {bot_choice}\nResult: {result}")
    else:
        await message.reply("Usage: `.rps rock/paper/scissors`")

@Client.on_message(filters.command("8ball", Config.CMD_PREFIX) & filters.me)
async def eightball_command(client: Client, message: Message):
    if len(message.command) > 1:
        question = " ".join(message.command[1:])
        responses = [
            "It is certain.", "It is decidedly so.", "Without a doubt.", "Yes definitely.",
            "You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.",
            "Yes.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
            "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again.",
            "Don't count on it.", "My reply is no.", "My sources say no.", "Outlook not so good.",
            "Very doubtful."
        ]
        await message.reply(f"**🎱 Question:** {question}\n**Answer:** {random.choice(responses)}")
    else:
        await message.reply("Ask a question! Usage: `.8ball Am I cool?`")

# More fun commands: .meme, .chucknorris, .dadjoke, .wouldyourather, .neverhaveiever, .truth, .dare, .ship, .pp, .howgay, .rate, .f, .hack, .brazzers, .wasted, .triggered, .crime, .slap, .hug, .kiss, .pat, .bite, .lick, .poke, .feed, .punch, .kill, .cry, .smile, etc.
