from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import requests
import datetime

@Client.on_message(filters.command("weather", Config.CMD_PREFIX) & filters.me)
async def weather_command(client: Client, message: Message):
    if len(message.command) > 1:
        city = " ".join(message.command[1:])
        
        try:
            # Using wttr.in (no API key needed)
            response = requests.get(f"https://wttr.in/{city}?format=%l:+%c+%t,+%w,+%h,+%p,+%P,+%m")
            weather = response.text.strip()
            
            await message.reply(f"**🌤️ Weather in {city}**\n`{weather}`")
        except:
            await message.reply("**❌ Error fetching weather data!**")
    else:
        await message.reply("**Usage:** `.weather <city>`\n**Example:** `.weather London`")

@Client.on_message(filters.command("forecast", Config.CMD_PREFIX) & filters.me)
async def forecast_command(client: Client, message: Message):
    if len(message.command) > 1:
        city = " ".join(message.command[1:])
        
        try:
            response = requests.get(f"https://wttr.in/{city}?format=%c+%t+%w&days=3")
            forecast = response.text.strip()
            
            await message.reply(f"**📅 3-Day Forecast for {city}**\n`{forecast}`")
        except:
            await message.reply("**❌ Error fetching forecast!**")
    else:
        await message.reply("**Usage:** `.forecast <city>`")

@Client.on_message(filters.command("moon", Config.CMD_PREFIX) & filters.me)
async def moon_command(client: Client, message: Message):
    try:
        response = requests.get("http://api.farmsense.net/v1/moonphases/")
        data = response.json()
        
        moon_phase = data[0]['MoonPhase']
        illumination = data[0]['Illumination']
        age = data[0]['Age']
        
        text = f"""
**🌙 Moon Information**
**Phase:** {moon_phase}
**Illumination:** {illumination:.1f}%
**Age:** {age:.1f} days
**Date:** {datetime.datetime.now().strftime('%Y-%m-%d')}
"""
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching moon data!**")

@Client.on_message(filters.command("sun", Config.CMD_PREFIX) & filters.me)
async def sun_command(client: Client, message: Message):
    if len(message.command) > 1:
        city = " ".join(message.command[1:])
        
        try:
            # Get coordinates first
            geo = requests.get(f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1")
            geo_data = geo.json()
            
            if geo_data.get('results'):
                lat = geo_data['results'][0]['latitude']
                lon = geo_data['results'][0]['longitude']
                
                # Get sun data
                sun = requests.get(f"https://api.sunrise-sunset.org/json?lat={lat}&lng={lon}&formatted=0")
                sun_data = sun.json()
                
                sunrise = datetime.datetime.fromisoformat(sun_data['results']['sunrise']).strftime('%H:%M:%S')
                sunset = datetime.datetime.fromisoformat(sun_data['results']['sunset']).strftime('%H:%M:%S')
                day_length = sun_data['results']['day_length']
                
                hours = day_length // 3600
                minutes = (day_length % 3600) // 60
                
                text = f"""
**☀️ Sun Information for {city}**
**Sunrise:** {sunrise}
**Sunset:** {sunset}
**Day Length:** {hours}h {minutes}m
**Solar Noon:** {sun_data['results']['solar_noon']}
"""
                await message.reply(text)
            else:
                await message.reply(f"**❌ City '{city}' not found!**")
        except:
            await message.reply("**❌ Error fetching sun data!**")
    else:
        await message.reply("**Usage:** `.sun <city>`")

# More weather commands: .airquality, .uvindex, .humidity, .pressure, .wind, .clouds, .rain, .snow, .storm, .tornado, .hurricane, .earthquake, .tsunami, .volcano, .flood, .wildfire
