from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import math
import random
import statistics

@Client.on_message(filters.command("calc", Config.CMD_PREFIX) & filters.me)
async def calc_command(client: Client, message: Message):
    if len(message.command) > 1:
        expr = " ".join(message.command[1:])
        try:
            result = eval(expr, {"__builtins__": {}}, math.__dict__)
            await message.reply(f"**📊 Calculation**\n`{expr} = {result}`")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("Usage: `.calc 2+2`")

@Client.on_message(filters.command("math", Config.CMD_PREFIX) & filters.me)
async def math_command(client: Client, message: Message):
    if len(message.command) > 2:
        op = message.command[1]
        nums = [float(x) for x in message.command[2:]]
        
        operations = {
            "add": sum,
            "sum": sum,
            "sub": lambda x: x[0] - x[1] if len(x) == 2 else None,
            "mul": lambda x: x[0] * x[1] if len(x) == 2 else None,
            "div": lambda x: x[0] / x[1] if len(x) == 2 else None,
            "pow": lambda x: x[0] ** x[1] if len(x) == 2 else None,
            "sqrt": lambda x: math.sqrt(x[0]),
            "sin": lambda x: math.sin(x[0]),
            "cos": lambda x: math.cos(x[0]),
            "tan": lambda x: math.tan(x[0]),
            "log": lambda x: math.log(x[0]) if len(x) == 1 else math.log(x[0], x[1]),
            "avg": statistics.mean,
            "mean": statistics.mean,
            "median": statistics.median,
            "mode": statistics.mode,
            "stdev": statistics.stdev,
            "variance": statistics.variance
        }
        
        if op in operations:
            try:
                result = operations[op](nums)
                await message.reply(f"**📊 {op}**\n**Result:** {result}")
            except Exception as e:
                await message.reply(f"**❌ Error:** {str(e)}")
        else:
            await message.reply("**❌ Unknown operation!**")
    else:
        await message.reply("Usage: `.math add 5 3`")

@Client.on_message(filters.command("prime", Config.CMD_PREFIX) & filters.me)
async def prime_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            num = int(message.command[1])
            if num < 2:
                await message.reply(f"**{num}** is NOT a prime number.")
                return
            
            is_prime = True
            for i in range(2, int(math.sqrt(num)) + 1):
                if num % i == 0:
                    is_prime = False
                    break
            
            if is_prime:
                await message.reply(f"**{num}** is a prime number! ✅")
            else:
                await message.reply(f"**{num}** is NOT a prime number. ❌")
        except:
            await message.reply("**❌ Invalid number!**")
    else:
        await message.reply("Usage: `.prime 17`")

@Client.on_message(filters.command("factor", Config.CMD_PREFIX) & filters.me)
async def factor_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            num = int(message.command[1])
            factors = []
            for i in range(1, num + 1):
                if num % i == 0:
                    factors.append(i)
            
            await message.reply(f"**🔢 Factors of {num}:**\n{', '.join(map(str, factors))}")
        except:
            await message.reply("**❌ Invalid number!**")
    else:
        await message.reply("Usage: `.factor 24`")

@Client.on_message(filters.command("fibonacci", Config.CMD_PREFIX) & filters.me)
async def fibonacci_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            n = int(message.command[1])
            if n > 100:
                await message.reply("**❌ Number too large! Max 100.**")
                return
            
            fib = [0, 1]
            for i in range(2, n):
                fib.append(fib[-1] + fib[-2])
            
            await message.reply(f"**🔢 Fibonacci ({n} terms):**\n{', '.join(map(str, fib[:n]))}")
        except:
            await message.reply("**❌ Invalid number!**")
    else:
        await message.reply("Usage: `.fibonacci 10`")

@Client.on_message(filters.command("table", Config.CMD_PREFIX) & filters.me)
async def table_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            num = int(message.command[1])
            limit = int(message.command[2]) if len(message.command) > 2 else 10
            
            text = f"**📊 Multiplication Table of {num}**\n\n"
            for i in range(1, limit + 1):
                text += f"{num} × {i} = {num * i}\n"
            
            await message.reply(text)
        except:
            await message.reply("**❌ Invalid input!**")
    else:
        await message.reply("Usage: `.table 7` or `.table 7 15`")

@Client.on_message(filters.command("percentage", Config.CMD_PREFIX) & filters.me)
async def percentage_command(client: Client, message: Message):
    if len(message.command) > 2:
        try:
            part = float(message.command[1])
            whole = float(message.command[2])
            percent = (part / whole) * 100
            await message.reply(f"**📊 Percentage:** {part} is {percent:.2f}% of {whole}")
        except:
            await message.reply("**❌ Invalid numbers!**")
    else:
        await message.reply("Usage: `.percentage 25 100`")

@Client.on_message(filters.command("sqrt", Config.CMD_PREFIX) & filters.me)
async def sqrt_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            num = float(message.command[1])
            result = math.sqrt(num)
            await message.reply(f"**√{num} = {result}**")
        except:
            await message.reply("**❌ Invalid number!**")
    else:
        await message.reply("Usage: `.sqrt 16`")

# More math commands: .sin, .cos, .tan, .asin, .acos, .atan, .log, .ln, .log10, .exp, .factorial, .perm, .comb, .gcd, .lcm, .mod, .abs, .round, .floor, .ceil, .trunc, .degrees, .radians, .pi, .e, .tau, .inf, .nan, .isclose, .isfinite, .isinf, .isnan, .dist, .hypot, .atan2, .copysign, .fmod, .remainder, .fsum, .prod, .perm, .comb, .binomial, .poisson, .normal, etc.
