from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ChatType, ChatMemberStatus
from config import Config
import asyncio
import os
import time

@Client.on_message(filters.command("del", Config.CMD_PREFIX) & filters.me)
async def delete_command(client: Client, message: Message):
    if message.reply_to_message:
        await message.reply_to_message.delete()
        await message.delete()
    else:
        await message.delete()

@Client.on_message(filters.command("copy", Config.CMD_PREFIX) & filters.me)
async def copy_command(client: Client, message: Message):
    if message.reply_to_message:
        await message.reply_to_message.copy(message.chat.id)
    else:
        await message.reply("**Reply to a message to copy it!**")

@Client.on_message(filters.command("forward", Config.CMD_PREFIX) & filters.me)
async def forward_command(client: Client, message: Message):
    if len(message.command) > 1 and message.reply_to_message:
        try:
            chat_id = int(message.command[1])
            await message.reply_to_message.forward(chat_id)
            await message.reply(f"**✅ Message forwarded to `{chat_id}`**")
        except:
            await message.reply("**❌ Invalid chat ID!**")
    else:
        await message.reply("**Usage:** `.forward <chat_id>` while replying to a message")

@Client.on_message(filters.command("id", Config.CMD_PREFIX) & filters.me)
async def id_command(client: Client, message: Message):
    text = f"""
**📋 ID Information**
**Chat ID:** `{message.chat.id}`
**User ID:** `{message.from_user.id}`
"""
    if message.reply_to_message:
        text += f"**Replied User ID:** `{message.reply_to_message.from_user.id}`\n"
    
    await message.reply(text)

@Client.on_message(filters.command("info", Config.CMD_PREFIX) & filters.me)
async def info_command(client: Client, message: Message):
    if message.reply_to_message:
        user = message.reply_to_message.from_user
    else:
        user = message.from_user
    
    # Get user photo
    photos = await client.get_chat_photos(user.id)
    photo_count = len(photos)
    
    text = f"""
**👤 User Info**
**ID:** `{user.id}`
**Name:** {user.first_name} {user.last_name or ''}
**Username:** @{user.username if user.username else 'None'}
**DC ID:** {getattr(user, 'dc_id', 'N/A')}
**Is Bot:** {user.is_bot}
**Is Premium:** {getattr(user, 'is_premium', False)}
**Photos:** {photo_count}
**Status:** {getattr(user, 'status', 'N/A')}
"""
    await message.reply(text)

@Client.on_message(filters.command("chat", Config.CMD_PREFIX) & filters.me)
async def chat_command(client: Client, message: Message):
    chat = message.chat
    
    members = await client.get_chat_members_count(chat.id)
    
    text = f"""
**💬 Chat Info**
**ID:** `{chat.id}`
**Title:** {chat.title if chat.title else 'Private'}
**Type:** {chat.type.name}
**Members:** {members}
**Username:** @{chat.username if chat.username else 'None'}
**Description:** {chat.description if chat.description else 'None'}
"""
    await message.reply(text)

@Client.on_message(filters.command("admins", Config.CMD_PREFIX) & filters.me)
async def admins_command(client: Client, message: Message):
    if message.chat.type == ChatType.PRIVATE:
        await message.reply("**❌ This command only works in groups!**")
        return
    
    admins = []
    async for member in client.get_chat_members(message.chat.id, filter="administrators"):
        admins.append(f"• {member.user.first_name} (@{member.user.username if member.user.username else 'None'})")
    
    text = f"**👑 Admins ({len(admins)}):**\n" + "\n".join(admins)
    await message.reply(text)

@Client.on_message(filters.command("bots", Config.CMD_PREFIX) & filters.me)
async def bots_command(client: Client, message: Message):
    if message.chat.type == ChatType.PRIVATE:
        await message.reply("**❌ This command only works in groups!**")
        return
    
    bots = []
    async for member in client.get_chat_members(message.chat.id):
        if member.user.is_bot:
            bots.append(f"• {member.user.first_name} (@{member.user.username})")
    
    text = f"**🤖 Bots ({len(bots)}):**\n" + "\n".join(bots) if bots else "**No bots in this chat!**"
    await message.reply(text)

@Client.on_message(filters.command("invite", Config.CMD_PREFIX) & filters.me)
async def invite_command(client: Client, message: Message):
    if len(message.command) > 1:
        try:
            username = message.command[1]
            user = await client.get_users(username)
            
            if message.chat.type != ChatType.PRIVATE:
                await client.add_chat_members(message.chat.id, user.id)
                await message.reply(f"**✅ Invited {user.first_name} to the chat!**")
            else:
                await message.reply("**❌ This command only works in groups!**")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.invite <username>`")

@Client.on_message(filters.command("link", Config.CMD_PREFIX) & filters.me)
async def link_command(client: Client, message: Message):
    try:
        invite_link = await client.create_chat_invite_link(message.chat.id)
        await message.reply(f"**🔗 Invite Link:**\n{invite_link.invite_link}")
    except:
        await message.reply("**❌ Cannot create invite link!**")

@Client.on_message(filters.command("purge", Config.CMD_PREFIX) & filters.me)
async def purge_command(client: Client, message: Message):
    if message.reply_to_message:
        msgs = []
        start_id = message.reply_to_message.id
        end_id = message.id
        
        async for msg in client.get_chat_history(message.chat.id, limit=100):
            if msg.id >= start_id and msg.id <= end_id:
                msgs.append(msg.id)
        
        if msgs:
            await client.delete_messages(message.chat.id, msgs)
            status = await message.reply(f"**✅ Purged {len(msgs)} messages!**")
            await asyncio.sleep(3)
            await status.delete()
    else:
        await message.reply("**Reply to the first message to purge!**")

@Client.on_message(filters.command("pin", Config.CMD_PREFIX) & filters.me)
async def pin_command(client: Client, message: Message):
    if message.reply_to_message:
        await client.pin_chat_message(message.chat.id, message.reply_to_message.id)
        await message.reply("**📌 Message pinned!**")
    else:
        await message.reply("**Reply to a message to pin it!**")

@Client.on_message(filters.command("unpin", Config.CMD_PREFIX) & filters.me)
async def unpin_command(client: Client, message: Message):
    if message.reply_to_message:
        await client.unpin_chat_message(message.chat.id, message.reply_to_message.id)
        await message.reply("**📌 Message unpinned!**")
    else:
        await message.reply("**Reply to a message to unpin it!**")

@Client.on_message(filters.command("unpinall", Config.CMD_PREFIX) & filters.me)
async def unpinall_command(client: Client, message: Message):
    try:
        await client.unpin_all_chat_messages(message.chat.id)
        await message.reply("**📌 All messages unpinned!**")
    except:
        await message.reply("**❌ Cannot unpin all messages!**")

# More Telegram commands: .export, .import, .backup, .restore, .stats, .top, .active, .inactive, .left, .joined, .kicked, .banned, .restricted, .promote, .demote, .setphoto, .settitle, .setdesc, .setusername, .setrules, .setabout, .setlinked, .setslow, .setantispam, .setlang, .setwelcome, .setgoodbye, .testwelcome, .testgoodbye
