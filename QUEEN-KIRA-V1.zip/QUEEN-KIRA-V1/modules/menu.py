from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from config import Config

# Define modules with their commands
MODULES = {
    "core": {
        "name": "⚙️ Core",
        "commands": [
            ".help - Show help menu",
            ".alive - Check if userbot is running",
            ".ping - Check response time",
            ".restart - Restart userbot",
            ".sysinfo - System information",
            ".botinfo - Bot information",
        ]
    },
    "admin": {
        "name": "👑 Admin",
        "commands": [
            ".ban - Ban user",
            ".unban - Unban user",
            ".kick - Kick user",
            ".mute - Mute user",
            ".unmute - Unmute user",
            ".pin - Pin message",
            ".unpin - Unpin message",
            ".purge - Delete multiple messages",
            ".del - Delete replied message",
            ".promote - Promote user",
            ".demote - Demote admin",
            ".invite - Invite user",
            ".admins - List admins",
            ".bots - List bots",
            ".warn - Warn user",
            ".notes - List notes",
        ]
    },
    "fun": {
        "name": "🎮 Fun",
        "commands": [
            ".joke - Random joke",
            ".roast - Roast a user",
            ".insult - Insult a user",
            ".compliment - Compliment a user",
            ".fact - Random fact",
            ".coinflip - Flip a coin",
            ".dice - Roll dice",
            ".rps - Rock paper scissors",
            ".8ball - Magic 8ball",
            ".ship - Ship two users",
            ".pp - PP size meter",
            ".howgay - Gay meter",
            ".rate - Rate something",
            ".slap - Slap a user",
            ".hug - Hug a user",
            ".kiss - Kiss a user",
            ".pat - Pat a user",
            ".tableflip - Flip table",
        ]
    },
    "utilities": {
        "name": "🛠️ Utilities",
        "commands": [
            ".id - Get user/chat ID",
            ".whois - User information",
            ".chatid - Get chat ID",
            ".chatinfo - Chat information",
            ".speedtest - Internet speed test",
            ".json - Get message JSON",
            ".calc - Calculator",
            ".math - Math operations",
            ".prime - Check if prime",
            ".factor - Get factors",
            ".fibonacci - Fibonacci sequence",
            ".table - Multiplication table",
            ".percentage - Calculate percentage",
            ".sqrt - Square root",
            ".hash - Generate hash",
        ]
    },
    "text": {
        "name": "🔤 Text",
        "commands": [
            ".upper - Uppercase text",
            ".lower - Lowercase text",
            ".capitalize - Capitalize text",
            ".title - Title case",
            ".reverse - Reverse text",
            ".count - Count characters",
            ".wrap - Wrap text",
            ".center - Center text",
            ".split - Split text",
            ".join - Join text",
            ".replace - Replace text",
        ]
    },
    "convert": {
        "name": "🔄 Convert",
        "commands": [
            ".unit - Unit conversion",
            ".currency - Currency conversion",
            ".json2csv - JSON to CSV",
            ".csv2json - CSV to JSON",
            ".img2txt - Image to ASCII",
            ".base64 - Base64 encode/decode",
            ".binary - Binary encode/decode",
            ".hex - Hex encode/decode",
            ".rot13 - ROT13 cipher",
        ]
    },
    "anime": {
        "name": "🎌 Anime",
        "commands": [
            ".anime - Anime info",
            ".manga - Manga info",
            ".character - Character info",
            ".waifu - Random waifu",
            ".neko - Random neko",
            ".topanime - Top anime",
        ]
    },
    "crypto": {
        "name": "💰 Crypto",
        "commands": [
            ".btc - Bitcoin price",
            ".eth - Ethereum price",
            ".crypto - Crypto price",
            ".gas - Gas fees",
        ]
    },
    "weather": {
        "name": "🌤️ Weather",
        "commands": [
            ".weather - Current weather",
            ".forecast - Weather forecast",
            ".moon - Moon phase",
        ]
    },
    "translate": {
        "name": "🌐 Translate",
        "commands": [
            ".tr - Translate text",
            ".langs - Supported languages",
            ".detect - Detect language",
        ]
    },
    "memes": {
        "name": "🎭 Memes",
        "commands": [
            ".meme - Random meme",
            ".dankmeme - Dank meme",
            ".wholesome - Wholesome meme",
            ".programmermeme - Programmer meme",
            ".memesub - Meme from subreddit",
            ".mock - Mock text",
            ".clap - Add clap emoji",
            ".shrug - Shrug emoji",
            ".lenny - Lenny face",
        ]
    },
    "stickers": {
        "name": "🎯 Stickers",
        "commands": [
            ".kang - Add sticker",
            ".stickerid - Get sticker ID",
            ".stickerpack - Pack info",
            ".sticker2img - Sticker to image",
            ".stext - Text sticker",
            ".squote - Quote sticker",
            ".catsticker - Cat sticker",
            ".dogsticker - Dog sticker",
        ]
    },
    "developer": {
        "name": "👨‍💻 Developer",
        "commands": [
            ".eval - Evaluate Python",
            ".exec - Execute Python",
            ".bash - Run bash command",
            ".pip - Run pip command",
            ".logs - View logs",
        ]
    }
}

# Calculate total commands
total_cmds = sum(len(cmds) for cmds in MODULES.values())

@Client.on_message(filters.command("menu", Config.CMD_PREFIX) & filters.me)
async def menu_command(client: Client, message: Message):
    """Show main menu"""
    
    # Create main menu text
    text = f"""
**🎯 Thomas Samuel Queen Kira UserBot**
**Version:** `{Config.BOT_VERSION}`
**Total Commands:** `{total_cmds}+`

**📌 Available Modules:**
"""
    
    # Create keyboard
    keyboard = []
    row = []
    
    for i, (module_id, module) in enumerate(MODULES.items(), 1):
        # Add to text
        text += f"├ {module['name']}\n"
        
        # Add to keyboard
        button = InlineKeyboardButton(
            module['name'],
            callback_data=f"mod_{module_id}"
        )
        row.append(button)
        
        if i % 2 == 0:
            keyboard.append(row)
            row = []
    
    if row:
        keyboard.append(row)
    
    # Add close button
    keyboard.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    
    text += f"\n**👤 Owner:** {Config.BOT_OWNER}"
    
    await message.reply(text, reply_markup=InlineKeyboardMarkup(keyboard))

@Client.on_callback_query(filters.regex(r"^mod_"))
async def module_callback(client: Client, callback_query):
    """Show module commands"""
    module_id = callback_query.data.replace("mod_", "")
    
    if module_id in MODULES:
        module = MODULES[module_id]
        
        # Create commands text
        text = f"**{module['name']} Module**\n"
        text += f"**Commands ({len(module['commands'])}):**\n\n"
        
        for cmd in module['commands']:
            text += f"`{cmd}`\n"
        
        # Add back button
        keyboard = [[
            InlineKeyboardButton("◀️ Back", callback_data="back"),
            InlineKeyboardButton("❌ Close", callback_data="close")
        ]]
        
        await callback_query.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        await callback_query.answer()

@Client.on_callback_query(filters.regex(r"^back$"))
async def back_callback(client: Client, callback_query):
    """Go back to main menu"""
    
    text = f"""
**🎯 Thomas Samuel Queen Kira UserBot**
**Version:** `{Config.BOT_VERSION}`
**Total Commands:** `{total_cmds}+`

**📌 Available Modules:**
"""
    
    # Recreate keyboard
    keyboard = []
    row = []
    
    for i, (module_id, module) in enumerate(MODULES.items(), 1):
        text += f"├ {module['name']}\n"
        
        button = InlineKeyboardButton(
            module['name'],
            callback_data=f"mod_{module_id}"
        )
        row.append(button)
        
        if i % 2 == 0:
            keyboard.append(row)
            row = []
    
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("❌ Close", callback_data="close")])
    
    text += f"\n**👤 Owner:** {Config.BOT_OWNER}"
    
    await callback_query.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    await callback_query.answer()

@Client.on_callback_query(filters.regex(r"^close$"))
async def close_callback(client: Client, callback_query):
    """Close the menu"""
    await callback_query.message.delete()
    await callback_query.answer("Menu closed")

@Client.on_message(filters.command("help", Config.CMD_PREFIX) & filters.me)
async def help_command(client: Client, message: Message):
    """Alias for menu"""
    await menu_command(client, message)

@Client.on_message(filters.command("modules", Config.CMD_PREFIX) & filters.me)
async def modules_command(client: Client, message: Message):
    """List all modules"""
    text = "**📦 Available Modules:**\n\n"
    
    for module_id, module in MODULES.items():
        text += f"{module['name']} - `{len(module['commands'])}` commands\n"
    
    text += f"\n**Total:** `{total_cmds}+` commands"
    
    await message.reply(text)

@Client.on_message(filters.command("cmd", Config.CMD_PREFIX) & filters.me)
async def cmd_command(client: Client, message: Message):
    """Search for a command"""
    if len(message.command) > 1:
        search = " ".join(message.command[1:]).lower()
        results = []
        
        for module_id, module in MODULES.items():
            for cmd in module['commands']:
                if search in cmd.lower():
                    results.append(f"{module['name']}: `{cmd}`")
        
        if results:
            text = f"**🔍 Found {len(results)} commands:**\n\n"
            text += "\n".join(results[:20])
            await message.reply(text)
        else:
            await message.reply(f"**❌ No commands found for '{search}'**")
    else:
        await message.reply("**Usage:** `.cmd <search>`")

print("✅ Menu module loaded with", total_cmds, "commands")
