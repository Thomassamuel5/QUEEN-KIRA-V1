from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
from googletrans import Translator
import pycountry

translator = Translator()

@Client.on_message(filters.command("tr", Config.CMD_PREFIX) & filters.me)
async def translate_command(client: Client, message: Message):
    if len(message.command) > 1:
        dest = message.command[1]
        text = " ".join(message.command[2:]) if len(message.command) > 2 else ""
        
        if not text and message.reply_to_message and message.reply_to_message.text:
            text = message.reply_to_message.text
        
        if text:
            try:
                translated = translator.translate(text, dest=dest)
                
                # Get language names
                src_lang = pycountry.languages.get(alpha_2=translated.src)
                dest_lang = pycountry.languages.get(alpha_2=dest)
                
                src_name = src_lang.name if src_lang else translated.src
                dest_name = dest_lang.name if dest_lang else dest
                
                await message.reply(f"""
**🌐 Translation ({src_name} ➜ {dest_name})**
**Original:** {text[:500]}{'...' if len(text) > 500 else ''}
**Translated:** {translated.text[:500]}{'...' if len(translated.text) > 500 else ''}
""")
            except Exception as e:
                await message.reply(f"**❌ Translation Error:** {str(e)}")
        else:
            await message.reply("**❌ No text to translate!**")
    else:
        await message.reply("**Usage:** `.tr <lang_code> <text>` or reply to a message\n**Example:** `.tr es Hello world`")

@Client.on_message(filters.command("langs", Config.CMD_PREFIX) & filters.me)
async def langs_command(client: Client, message: Message):
    languages = """
**🌐 Supported Languages**
**ar** - Arabic
**bn** - Bengali
**zh** - Chinese
**nl** - Dutch
**en** - English
**fr** - French
**de** - German
**el** - Greek
**gu** - Gujarati
**hi** - Hindi
**id** - Indonesian
**it** - Italian
**ja** - Japanese
**kn** - Kannada
**ko** - Korean
**ml** - Malayalam
**mr** - Marathi
**ne** - Nepali
**fa** - Persian
**pl** - Polish
**pt** - Portuguese
**pa** - Punjabi
**ru** - Russian
**es** - Spanish
**ta** - Tamil
**te** - Telugu
**th** - Thai
**tr** - Turkish
**uk** - Ukrainian
**ur** - Urdu
**vi** - Vietnamese
"""
    await message.reply(languages)

@Client.on_message(filters.command("detect", Config.CMD_PREFIX) & filters.me)
async def detect_command(client: Client, message: Message):
    text = " ".join(message.command[1:]) if len(message.command) > 1 else ""
    
    if not text and message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
    
    if text:
        try:
            detected = translator.detect(text)
            lang = pycountry.languages.get(alpha_2=detected.lang)
            lang_name = lang.name if lang else detected.lang
            
            await message.reply(f"**🔍 Detected Language:** {lang_name}\n**Confidence:** {detected.confidence:.2%}")
        except Exception as e:
            await message.reply(f"**❌ Detection Error:** {str(e)}")
    else:
        await message.reply("**❌ No text to detect!**")

# More translate commands: .tts, .ocr, .define, .synonym, .antonym, .rhyme, .pronounce, .spell, .grammar, .thesaurus, .dictionary, .urban, .wiktionary, .etymology, .wordoftheday
