from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import json
import csv
import io
import os
import datetime

@Client.on_message(filters.command("unit", Config.CMD_PREFIX) & filters.me)
async def unit_command(client: Client, message: Message):
    if len(message.command) > 3:
        value = float(message.command[1])
        from_unit = message.command[2].lower()
        to_unit = message.command[3].lower()
        
        # Length conversions
        length_units = {
            'mm': 0.001, 'cm': 0.01, 'm': 1, 'km': 1000,
            'in': 0.0254, 'ft': 0.3048, 'yd': 0.9144, 'mi': 1609.344
        }
        
        # Weight conversions
        weight_units = {
            'mg': 0.000001, 'g': 0.001, 'kg': 1, 't': 1000,
            'oz': 0.0283495, 'lb': 0.453592, 'stone': 6.35029
        }
        
        # Temperature conversions
        temp_units = ['c', 'f', 'k']
        
        # Check which category
        if from_unit in length_units and to_unit in length_units:
            # Convert to meters first, then to target
            meters = value * length_units[from_unit]
            result = meters / length_units[to_unit]
            category = "Length"
        elif from_unit in weight_units and to_unit in weight_units:
            # Convert to kg first, then to target
            kg = value * weight_units[from_unit]
            result = kg / weight_units[to_unit]
            category = "Weight"
        elif from_unit in temp_units and to_unit in temp_units:
            # Temperature conversions
            if from_unit == 'c':
                if to_unit == 'f':
                    result = (value * 9/5) + 32
                elif to_unit == 'k':
                    result = value + 273.15
                else:
                    result = value
            elif from_unit == 'f':
                if to_unit == 'c':
                    result = (value - 32) * 5/9
                elif to_unit == 'k':
                    result = (value - 32) * 5/9 + 273.15
                else:
                    result = value
            elif from_unit == 'k':
                if to_unit == 'c':
                    result = value - 273.15
                elif to_unit == 'f':
                    result = (value - 273.15) * 9/5 + 32
                else:
                    result = value
            category = "Temperature"
        else:
            await message.reply("**❌ Incompatible units!**")
            return
        
        await message.reply(f"""
**🔄 Unit Conversion ({category})**
**{value} {from_unit} = {result:.4f} {to_unit}**
""")
    else:
        await message.reply("**Usage:** `.unit <value> <from> <to>`\n**Example:** `.unit 100 cm m`")

@Client.on_message(filters.command("currency", Config.CMD_PREFIX) & filters.me)
async def currency_command(client: Client, message: Message):
    if len(message.command) > 3:
        amount = float(message.command[1])
        from_curr = message.command[2].upper()
        to_curr = message.command[3].upper()
        
        try:
            import requests
            response = requests.get(f"https://api.exchangerate-api.com/v4/latest/{from_curr}")
            data = response.json()
            
            if to_curr in data['rates']:
                rate = data['rates'][to_curr]
                result = amount * rate
                await message.reply(f"""
**💱 Currency Conversion**
**{amount} {from_curr} = {result:.2f} {to_curr}**
**Rate:** 1 {from_curr} = {rate} {to_curr}
**Date:** {data['date']}
""")
            else:
                await message.reply(f"**❌ Unknown currency: {to_curr}**")
        except:
            await message.reply("**❌ Error fetching exchange rates!**")
    else:
        await message.reply("**Usage:** `.currency <amount> <from> <to>`\n**Example:** `.currency 100 USD EUR`")

@Client.on_message(filters.command("json2csv", Config.CMD_PREFIX) & filters.me)
async def json2csv_command(client: Client, message: Message):
    if message.reply_to_message and message.reply_to_message.document:
        file = await message.reply_to_message.download()
        
        try:
            with open(file, 'r') as f:
                data = json.load(f)
            
            if isinstance(data, list) and len(data) > 0:
                # Get headers
                headers = data[0].keys()
                
                # Create CSV
                output = io.StringIO()
                writer = csv.DictWriter(output, fieldnames=headers)
                writer.writeheader()
                writer.writerows(data)
                
                # Save to file
                csv_file = file.replace('.json', '.csv')
                with open(csv_file, 'w') as f:
                    f.write(output.getvalue())
                
                await message.reply_document(csv_file, caption="**✅ Converted JSON to CSV**")
                os.remove(csv_file)
            else:
                await message.reply("**❌ Invalid JSON format!**")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
        finally:
            os.remove(file)
    else:
        await message.reply("**Reply to a JSON file with `.json2csv`**")

@Client.on_message(filters.command("csv2json", Config.CMD_PREFIX) & filters.me)
async def csv2json_command(client: Client, message: Message):
    if message.reply_to_message and message.reply_to_message.document:
        file = await message.reply_to_message.download()
        
        try:
            import csv
            import json
            
            data = []
            with open(file, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    data.append(row)
            
            # Save to file
            json_file = file.replace('.csv', '.json')
            with open(json_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            await message.reply_document(json_file, caption="**✅ Converted CSV to JSON**")
            os.remove(json_file)
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
        finally:
            os.remove(file)
    else:
        await message.reply("**Reply to a CSV file with `.csv2json`**")

@Client.on_message(filters.command("img2txt", Config.CMD_PREFIX) & filters.me)
async def img2txt_command(client: Client, message: Message):
    if message.reply_to_message and message.reply_to_message.photo:
        file = await message.reply_to_message.download()
        
        try:
            from PIL import Image
            import numpy as np
            
            # ASCII characters for different brightness levels
            ascii_chars = '@%#*+=-:. '
            
            img = Image.open(file).convert('L')  # Convert to grayscale
            img = img.resize((100, 50))  # Resize for better viewing
            
            pixels = np.array(img)
            ascii_img = ""
            
            for row in pixels:
                for pixel in row:
                    idx = int(pixel / 255 * (len(ascii_chars) - 1))
                    ascii_img += ascii_chars[idx]
                ascii_img += "\n"
            
            await message.reply(f"**🎨 ASCII Art:**\n```\n{ascii_img}\n```")
            
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
        finally:
            os.remove(file)
    else:
        await message.reply("**Reply to an image with `.img2txt`**")

@Client.on_message(filters.command("txt2img", Config.CMD_PREFIX) & filters.me)
async def txt2img_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        
        try:
            from PIL import Image, ImageDraw, ImageFont
            
            # Create image
            img = Image.new('RGB', (800, 200), color='white')
            draw = ImageDraw.Draw(img)
            
            # Use default font
            try:
                font = ImageFont.truetype("arial.ttf", 20)
            except:
                font = ImageFont.load_default()
            
            # Draw text
            draw.text((10, 10), text, fill='black', font=font)
            
            # Save
            img_file = "text_image.png"
            img.save(img_file)
            
            await message.reply_photo(img_file, caption="**✅ Text converted to image**")
            os.remove(img_file)
            
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.txt2img <text>`")

# More convert commands: .mp3, .mp4, .gif, .webp, .sticker, .voice, .video, .audio, .doc, .pdf, .zip, .rar, .7z, .tar, .gz, .bz2, .xz, .base32, .base64, .hex, .bin, .oct, .dec, .roman, .morse, .braille, .emoji, .unicode, .ascii, .utf8, .utf16, .utf32
