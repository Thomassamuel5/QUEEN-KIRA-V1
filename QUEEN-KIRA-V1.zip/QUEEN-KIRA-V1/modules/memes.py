from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import requests
import random
import os
import json
from PIL import Image, ImageDraw, ImageFont
import textwrap

# ==================== MEME API COMMANDS ====================

@Client.on_message(filters.command("meme", Config.CMD_PREFIX) & filters.me)
async def meme_command(client: Client, message: Message):
    """Get a random meme from reddit"""
    status = await message.reply("**🔍 Fetching a fresh meme...**")
    
    subreddits = ["memes", "dankmemes", "wholesomememes", "me_irl", "AdviceAnimals", "ProgrammerHumor"]
    chosen = random.choice(subreddits)
    
    try:
        response = requests.get(f"https://meme-api.com/gimme/{chosen}")
        data = response.json()
        
        if data.get('url'):
            caption = f"**{data['title']}**\n"
            caption += f"📊 {data['ups']} upvotes | r/{data['subreddit']}\n"
            caption += f"🔗 [Link]({data['postLink']})"
            
            await status.delete()
            await message.reply_photo(data['url'], caption=caption)
        else:
            await status.edit_text("**❌ Couldn't fetch a meme. Try again!**")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("dankmeme", Config.CMD_PREFIX) & filters.me)
async def dankmeme_command(client: Client, message: Message):
    """Get a random dank meme"""
    status = await message.reply("**🔍 Fetching dank meme...**")
    
    try:
        response = requests.get("https://meme-api.com/gimme/dankmemes")
        data = response.json()
        
        if data.get('url'):
            caption = f"**{data['title']}**\n"
            caption += f"📊 {data['ups']} upvotes | r/dankmemes\n"
            caption += f"🔗 [Link]({data['postLink']})"
            
            await status.delete()
            await message.reply_photo(data['url'], caption=caption)
        else:
            await status.edit_text("**❌ Couldn't fetch a dank meme!**")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("wholesome", Config.CMD_PREFIX) & filters.me)
async def wholesome_command(client: Client, message: Message):
    """Get a random wholesome meme"""
    status = await message.reply("**🔍 Fetching wholesome meme...**")
    
    try:
        response = requests.get("https://meme-api.com/gimme/wholesomememes")
        data = response.json()
        
        if data.get('url'):
            caption = f"**{data['title']}**\n"
            caption += f"📊 {data['ups']} upvotes | r/wholesomememes\n"
            caption += f"🔗 [Link]({data['postLink']})"
            
            await status.delete()
            await message.reply_photo(data['url'], caption=caption)
        else:
            await status.edit_text("**❌ Couldn't fetch a wholesome meme!**")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("programmermeme", Config.CMD_PREFIX) & filters.me)
async def programmer_meme_command(client: Client, message: Message):
    """Get a random programmer meme"""
    status = await message.reply("**🔍 Fetching programmer meme...**")
    
    try:
        response = requests.get("https://meme-api.com/gimme/ProgrammerHumor")
        data = response.json()
        
        if data.get('url'):
            caption = f"**{data['title']}**\n"
            caption += f"📊 {data['ups']} upvotes | r/ProgrammerHumor\n"
            caption += f"🔗 [Link]({data['postLink']})"
            
            await status.delete()
            await message.reply_photo(data['url'], caption=caption)
        else:
            await status.edit_text("**❌ Couldn't fetch a programmer meme!**")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("memesub", Config.CMD_PREFIX) & filters.me)
async def memesub_command(client: Client, message: Message):
    """Get meme from specific subreddit"""
    if len(message.command) > 1:
        sub = message.command[1]
        status = await message.reply(f"**🔍 Fetching meme from r/{sub}...**")
        
        try:
            response = requests.get(f"https://meme-api.com/gimme/{sub}")
            data = response.json()
            
            if data.get('url'):
                caption = f"**{data['title']}**\n"
                caption += f"📊 {data['ups']} upvotes | r/{data['subreddit']}\n"
                caption += f"🔗 [Link]({data['postLink']})"
                
                await status.delete()
                await message.reply_photo(data['url'], caption=caption)
            else:
                await status.edit_text(f"**❌ Couldn't fetch from r/{sub}!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.memesub <subreddit>`\n**Example:** `.memesub cats`")

# ==================== IMGFLIP MEME GENERATOR ====================

# Popular meme templates with their IDs from Imgflip
MEME_TEMPLATES = {
    "drake": 181913649,  # Drake Hotline Bling
    "distracted": 112126428,  # Distracted Boyfriend
    "biden": 91538330,  # Biden
    "disaster": 216951317,  # Disaster Girl
    "change": 438680,  # Change My Mind
    "spongebob": 102156234,  # Mocking Spongebob
    "fry": 84688,  # Fry Shut Up And Take My Money
    "two": 87743020,  # Two Buttons
    "gru": 235589,  # Gru's Plan
    "leo": 89370399,  # Leo DiCaprio Cheers
    "waiting": 131087935,  # Waiting Skeleton
    "trade": 248885,  # Trade Offer
    "brain": 93895088,  # Expanding Brain
    "monkey": 444501,  # Monkey Puppet
    "womanyelling": 188390779,  # Woman Yelling At Cat
    "cat": 188390779,  # Woman Yelling At Cat (same ID)
    "office": 87743020,  # The Office (same as Two Buttons)
}

@Client.on_message(filters.command("mm", Config.CMD_PREFIX) & filters.me)
async def mm_command(client: Client, message: Message):
    """Generate meme with Imgflip - Usage: .mm <template> <top text> | <bottom text>"""
    if len(message.command) < 2:
        templates_list = "\n".join([f"• `{name}`" for name in MEME_TEMPLATES.keys()])
        await message.reply(f"**🎭 Available Meme Templates:**\n{templates_list}\n\n**Usage:** `.mm <template> <top text> | <bottom text>`\n**Example:** `.mm drake Python | JavaScript`")
        return
    
    # Parse command
    args = " ".join(message.command[1:]).split(" | ")
    template_name = message.command[1].lower()
    
    if len(args) == 2:
        top_text = args[0].replace(f"{message.command[1]} ", "")
        bottom_text = args[1]
    elif len(args) == 3:
        template_name = args[0].lower()
        top_text = args[1]
        bottom_text = args[2]
    else:
        await message.reply("**❌ Invalid format! Use:** `.mm template top text | bottom text`")
        return
    
    # Get template ID
    template_id = MEME_TEMPLATES.get(template_name)
    if not template_id:
        await message.reply(f"**❌ Template '{template_name}' not found!** Use `.mm` to see available templates.")
        return
    
    status = await message.reply("**🎨 Generating your meme...**")
    
    try:
        # Imgflip API - Note: You need to sign up for free at imgflip.com to get username/password
        # For now using anonymous access (limited)
        response = requests.post(
            "https://api.imgflip.com/caption_image",
            data={
                "template_id": template_id,
                "username": "",  # Optional: Add your imgflip username
                "password": "",  # Optional: Add your imgflip password
                "text0": top_text[:100],
                "text1": bottom_text[:100] if bottom_text else "",
            }
        )
        
        data = response.json()
        
        if data['success']:
            await status.delete()
            await message.reply_photo(
                data['data']['url'],
                caption=f"**🎭 Template:** {template_name}\n**Top:** {top_text}\n**Bottom:** {bottom_text}"
            )
        else:
            await status.edit_text(f"**❌ API Error:** {data['error_message']}")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

# ==================== LOCAL MEME GENERATOR ====================

@Client.on_message(filters.command("textmeme", Config.CMD_PREFIX) & filters.me)
async def textmeme_command(client: Client, message: Message):
    """Create a simple text meme - Usage: .textmeme <top text> | <bottom text>"""
    if len(message.command) < 2:
        await message.reply("**Usage:** `.textmeme <top text> | <bottom text>`\n**Example:** `.textmeme When you find a bug | It's not a bug, it's a feature`")
        return
    
    args = " ".join(message.command[1:]).split(" | ")
    
    if len(args) != 2:
        await message.reply("**❌ Please use the format: `<top text> | <bottom text>`**")
        return
    
    top_text = args[0]
    bottom_text = args[1]
    
    status = await message.reply("**🎨 Creating text meme...**")
    
    try:
        # Create a simple image with Impact font
        img = Image.new('RGB', (800, 600), color='white')
        draw = ImageDraw.Draw(img)
        
        # Try to load Impact font, fallback to default
        try:
            # Common paths for Impact font
            font_paths = [
                "/usr/share/fonts/truetype/msttcorefonts/Impact.ttf",
                "/usr/share/fonts/TTF/Impact.ttf",
                "C:/Windows/Fonts/impact.ttf",
                "/System/Library/Fonts/Impact.ttf"
            ]
            font = None
            for path in font_paths:
                if os.path.exists(path):
                    font = ImageFont.truetype(path, 60)
                    break
            if not font:
                font = ImageFont.load_default()
        except:
            font = ImageFont.load_default()
        
        # Draw top text
        top_lines = textwrap.wrap(top_text, width=20)
        y_position = 50
        for line in top_lines:
            text_width = draw.textlength(line, font=font)
            x_position = (img.width - text_width) / 2
            draw.text((x_position, y_position), line, fill='black', font=font)
            y_position += 70
        
        # Draw bottom text
        bottom_lines = textwrap.wrap(bottom_text, width=20)
        y_position = img.height - 100 - (len(bottom_lines) * 70)
        for line in bottom_lines:
            text_width = draw.textlength(line, font=font)
            x_position = (img.width - text_width) / 2
            draw.text((x_position, y_position), line, fill='black', font=font)
            y_position += 70
        
        # Save and send
        meme_path = "text_meme.png"
        img.save(meme_path)
        
        await status.delete()
        await message.reply_photo(
            meme_path,
            caption=f"**🎭 Text Meme**\n**Top:** {top_text}\n**Bottom:** {bottom_text}"
        )
        
        os.remove(meme_path)
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

# ==================== MEME UTILITIES ====================

@Client.on_message(filters.command("memelist", Config.CMD_PREFIX) & filters.me)
async def memelist_command(client: Client, message: Message):
    """List all available meme templates"""
    templates_list = "\n".join([f"• `{name}`" for name in sorted(MEME_TEMPLATES.keys())])
    await message.reply(f"**🎭 Available Meme Templates ({len(MEME_TEMPLATES)}):**\n{templates_list}\n\n**Usage:** `.mm <template> <top> | <bottom>`")

@Client.on_message(filters.command("memestats", Config.CMD_PREFIX) & filters.me)
async def memestats_command(client: Client, message: Message):
    """Get meme statistics"""
    status = await message.reply("**📊 Fetching meme stats...**")
    
    try:
        response = requests.get("https://meme-api.com/status")
        data = response.json()
        
        text = f"""
**📊 Meme API Statistics**
**Total Memes:** {data.get('total_memes', 'N/A')}
**Total Posts:** {data.get('total_posts', 'N/A')}
**Subreddits:** {data.get('subreddits', 'N/A')}
**Version:** {data.get('version', 'N/A')}
"""
        await status.edit_text(text)
    except:
        await status.edit_text("**❌ Couldn't fetch stats!**")

# ==================== MEME FUNNY COMMANDS ====================

@Client.on_message(filters.command("changemymind", Config.CMD_PREFIX) & filters.me)
async def changemymind_command(client: Client, message: Message):
    """Change My Mind meme - Usage: .changemymind <text>"""
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        
        try:
            # Use Imgflip API with Change My Mind template (ID: 438680)
            response = requests.post(
                "https://api.imgflip.com/caption_image",
                data={
                    "template_id": 438680,
                    "text0": text[:100],
                }
            )
            
            data = response.json()
            
            if data['success']:
                await message.reply_photo(
                    data['data']['url'],
                    caption=f"**🤔 Change My Mind:** {text}"
                )
            else:
                await message.reply(f"**❌ Error:** {data['error_message']}")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.changemymind <text>`")

@Client.on_message(filters.command("drake", Config.CMD_PREFIX) & filters.me)
async def drake_command(client: Client, message: Message):
    """Drake meme - Usage: .drake <bad> | <good>"""
    if len(message.command) > 2 and "|" in message.text:
        args = message.text.split("|")
        bad = args[0].replace(".drake", "").strip()
        good = args[1].strip()
        
        try:
            response = requests.post(
                "https://api.imgflip.com/caption_image",
                data={
                    "template_id": 181913649,
                    "text0": bad[:100],
                    "text1": good[:100],
                }
            )
            
            data = response.json()
            
            if data['success']:
                await message.reply_photo(
                    data['data']['url'],
                    caption=f"**🕺 Drake Meme**\n**Dislikes:** {bad}\n**Likes:** {good}"
                )
            else:
                await message.reply(f"**❌ Error:** {data['error_message']}")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.drake <bad thing> | <good thing>`\n**Example:** `.drake Waking up early | Sleeping in`")

@Client.on_message(filters.command("distracted", Config.CMD_PREFIX) & filters.me)
async def distracted_command(client: Client, message: Message):
    """Distracted Boyfriend meme - Usage: .distracted <girl> | <boyfriend> | <wife>"""
    if len(message.command) > 3 and "|" in message.text:
        parts = message.text.split("|")
        if len(parts) >= 3:
            girl = parts[0].replace(".distracted", "").strip()
            boyfriend = parts[1].strip()
            wife = parts[2].strip()
            
            try:
                response = requests.post(
                    "https://api.imgflip.com/caption_image",
                    data={
                        "template_id": 112126428,
                        "text0": girl[:100],
                        "text1": boyfriend[:100],
                        "text2": wife[:100],
                    }
                )
                
                data = response.json()
                
                if data['success']:
                    await message.reply_photo(
                        data['data']['url'],
                        caption=f"**😅 Distracted Boyfriend**\n**Girl:** {girl}\n**Boyfriend:** {boyfriend}\n**Wife:** {wife}"
                    )
                else:
                    await message.reply(f"**❌ Error:** {data['error_message']}")
            except Exception as e:
                await message.reply(f"**❌ Error:** {str(e)}")
        else:
            await message.reply("**Usage:** `.distracted <girl> | <boyfriend> | <wife>`")
    else:
        await message.reply("**Usage:** `.distracted <girl> | <boyfriend> | <wife>`\n**Example:** `.distracted Python | JavaScript | TypeScript`")

# ==================== RANDOM MEME GENERATORS ====================

@Client.on_message(filters.command("randommeme", Config.CMD_PREFIX) & filters.me)
async def randommeme_command(client: Client, message: Message):
    """Generate a random meme with random text"""
    templates = list(MEME_TEMPLATES.items())
    template_name, template_id = random.choice(templates)
    
    random_top = random.choice([
        "When you fix a bug", "Me trying to code", "Python vs JavaScript",
        "When it works", "My code after 3 hours", "When the boss is watching",
        "Me explaining bugs", "When I see legacy code", "Production ready",
        "It works on my machine"
    ])
    
    random_bottom = random.choice([
        "It breaks in production", "I have no idea what I'm doing",
        "I'll just use ChatGPT", "Time to refactor everything",
        "It's not a bug, it's a feature", "Works on my machine",
        "Stack Overflow to the rescue", "Copy-paste from GitHub",
        "Just one more line", "I'll fix it later"
    ])
    
    status = await message.reply(f"**🎨 Generating random {template_name} meme...**")
    
    try:
        response = requests.post(
            "https://api.imgflip.com/caption_image",
            data={
                "template_id": template_id,
                "text0": random_top[:100],
                "text1": random_bottom[:100],
            }
        )
        
        data = response.json()
        
        if data['success']:
            await status.delete()
            await message.reply_photo(
                data['data']['url'],
                caption=f"**🎲 Random Meme ({template_name})**\n**Top:** {random_top}\n**Bottom:** {random_bottom}"
            )
        else:
            await status.edit_text(f"**❌ Error:** {data['error_message']}")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

# ==================== MEME SEARCH ====================

@Client.on_message(filters.command("memesearch", Config.CMD_PREFIX) & filters.me)
async def memesearch_command(client: Client, message: Message):
    """Search for memes by keyword"""
    if len(message.command) > 1:
        query = " ".join(message.command[1:])
        status = await message.reply(f"**🔍 Searching for '{query}' memes...**")
        
        try:
            # Search Imgflip templates
            response = requests.get(f"https://api.imgflip.com/get_memes")
            data = response.json()
            
            if data['success']:
                memes = data['data']['memes']
                results = []
                
                for meme in memes:
                    if query.lower() in meme['name'].lower():
                        results.append(f"• `{meme['name']}` - ID: {meme['id']}")
                
                if results:
                    text = f"**🎭 Meme templates matching '{query}':**\n" + "\n".join(results[:15])
                    if len(results) > 15:
                        text += f"\n\n...and {len(results) - 15} more"
                else:
                    text = f"**❌ No templates found for '{query}'**"
                
                await status.edit_text(text)
            else:
                await status.edit_text("**❌ Couldn't fetch meme templates!**")
        except Exception as e:
            await status.edit_text(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.memesearch <keyword>`\n**Example:** `.memesearch cat`")

# ==================== MEME FUNNY TEXT ====================

@Client.on_message(filters.command("mock", Config.CMD_PREFIX) & filters.me)
async def mock_command(client: Client, message: Message):
    """Mock text like SpongeBob - Usage: .mock <text>"""
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        mocked = ""
        
        for i, char in enumerate(text):
            if i % 2 == 0:
                mocked += char.upper()
            else:
                mocked += char.lower()
        
        await message.reply(f"**😤 Mocked:**\n`{mocked}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        mocked = ""
        
        for i, char in enumerate(text):
            if i % 2 == 0:
                mocked += char.upper()
            else:
                mocked += char.lower()
        
        await message.reply(f"**😤 Mocked:**\n`{mocked}`")
    else:
        await message.reply("**Usage:** `.mock <text>` or reply to a message")

@Client.on_message(filters.command("clap", Config.CMD_PREFIX) & filters.me)
async def clap_command(client: Client, message: Message):
    """Add clap emoji between words - Usage: .clap <text>"""
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        clapped = text.replace(" ", " 👏 ")
        await message.reply(f"**👏 Clapify:**\n`{clapped}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        clapped = text.replace(" ", " 👏 ")
        await message.reply(f"**👏 Clapify:**\n`{clapped}`")
    else:
        await message.reply("**Usage:** `.clap <text>`")

@Client.on_message(filters.command("shrug", Config.CMD_PREFIX) & filters.me)
async def shrug_command(client: Client, message: Message):
    """Add shrug emoji - Usage: .shrug <text>"""
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"{text} ¯\\_(ツ)_/¯")
    else:
        await message.reply("¯\\_(ツ)_/¯")

@Client.on_message(filters.command("lenny", Config.CMD_PREFIX) & filters.me)
async def lenny_command(client: Client, message: Message):
    """Send lenny face"""
    await message.reply("( ͡° ͜ʖ ͡°)")

@Client.on_message(filters.command("tableflip", Config.CMD_PREFIX) & filters.me)
async def tableflip_command(client: Client, message: Message):
    """Send table flip"""
    await message.reply("(╯°□°）╯︵ ┻━┻")

@Client.on_message(filters.command("unflip", Config.CMD_PREFIX) & filters.me)
async def unflip_command(client: Client, message: Message):
    """Send table unflip"""
    await message.reply("┬─┬﻿ ノ( ゜-゜ノ)")

# ==================== MEME HELP ====================

@Client.on_message(filters.command("memehelp", Config.CMD_PREFIX) & filters.me)
async def memehelp_command(client: Client, message: Message):
    """Show meme module help"""
    help_text = """
**🎭 Memes Module Commands (25)**

**📥 API Memes:**
`.meme` - Random meme from reddit
`.dankmeme` - Random dank meme
`.wholesome` - Random wholesome meme
`.programmermeme` - Random programmer meme
`.memesub <sub>` - Meme from specific subreddit

**🎨 Meme Generator:**
`.mm <template> <top> | <bottom>` - Generate meme
`.memelist` - List all templates
`.changemymind <text>` - Change my mind meme
`.drake <bad> | <good>` - Drake meme
`.distracted <girl> | <boy> | <wife>` - Distracted boyfriend
`.textmeme <top> | <bottom>` - Simple text meme
`.randommeme` - Random meme with random text

**🔍 Utilities:**
`.memesearch <keyword>` - Search for templates
`.memestats` - Meme API statistics

**😄 Funny Text:**
`.mock <text>` - Mock text (SpongeBob style)
`.clap <text>` - Add 👏 between words
`.shrug` - Shrug emoji
`.lenny` - Lenny face
`.tableflip` - Flip table
`.unflip` - Unflip table

**Example:** `.mm drake Python | JavaScript`
"""
    await message.reply(help_text)
