from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import textwrap
import re
import random
import string
import hashlib
import base64
from urllib.parse import quote, unquote

@Client.on_message(filters.command("reverse", Config.CMD_PREFIX) & filters.me)
async def reverse_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        reversed_text = text[::-1]
        await message.reply(f"**🔄 Reversed:**\n`{reversed_text}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        reversed_text = text[::-1]
        await message.reply(f"**🔄 Reversed:**\n`{reversed_text}`")
    else:
        await message.reply("**Usage:** `.reverse <text>` or reply to a message")

@Client.on_message(filters.command("upper", Config.CMD_PREFIX) & filters.me)
async def upper_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"**⬆️ Uppercase:**\n`{text.upper()}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        await message.reply(f"**⬆️ Uppercase:**\n`{text.upper()}`")
    else:
        await message.reply("**Usage:** `.upper <text>`")

@Client.on_message(filters.command("lower", Config.CMD_PREFIX) & filters.me)
async def lower_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"**⬇️ Lowercase:**\n`{text.lower()}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        await message.reply(f"**⬇️ Lowercase:**\n`{text.lower()}`")
    else:
        await message.reply("**Usage:** `.lower <text>`")

@Client.on_message(filters.command("capitalize", Config.CMD_PREFIX) & filters.me)
async def capitalize_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"**📝 Capitalized:**\n`{text.capitalize()}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        await message.reply(f"**📝 Capitalized:**\n`{text.capitalize()}`")
    else:
        await message.reply("**Usage:** `.capitalize <text>`")

@Client.on_message(filters.command("title", Config.CMD_PREFIX) & filters.me)
async def title_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"**📝 Title Case:**\n`{text.title()}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        await message.reply(f"**📝 Title Case:**\n`{text.title()}`")
    else:
        await message.reply("**Usage:** `.title <text>`")

@Client.on_message(filters.command("swapcase", Config.CMD_PREFIX) & filters.me)
async def swapcase_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        await message.reply(f"**🔄 Swap Case:**\n`{text.swapcase()}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        await message.reply(f"**🔄 Swap Case:**\n`{text.swapcase()}`")
    else:
        await message.reply("**Usage:** `.swapcase <text>`")

@Client.on_message(filters.command("count", Config.CMD_PREFIX) & filters.me)
async def count_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        char_count = len(text)
        word_count = len(text.split())
        line_count = text.count('\n') + 1
        
        await message.reply(f"""
**📊 Text Statistics**
**Characters:** {char_count}
**Words:** {word_count}
**Lines:** {line_count}
**Spaces:** {text.count(' ')}
**Letters:** {sum(c.isalpha() for c in text)}
**Digits:** {sum(c.isdigit() for c in text)}
""")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        char_count = len(text)
        word_count = len(text.split())
        line_count = text.count('\n') + 1
        
        await message.reply(f"""
**📊 Text Statistics**
**Characters:** {char_count}
**Words:** {word_count}
**Lines:** {line_count}
**Spaces:** {text.count(' ')}
**Letters:** {sum(c.isalpha() for c in text)}
**Digits:** {sum(c.isdigit() for c in text)}
""")
    else:
        await message.reply("**Usage:** `.count <text>`")

@Client.on_message(filters.command("hash", Config.CMD_PREFIX) & filters.me)
async def hash_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:]).encode()
        
        md5 = hashlib.md5(text).hexdigest()
        sha1 = hashlib.sha1(text).hexdigest()
        sha256 = hashlib.sha256(text).hexdigest()
        sha512 = hashlib.sha512(text).hexdigest()
        
        await message.reply(f"""
**🔐 Hash Values**
**MD5:** `{md5}`
**SHA1:** `{sha1}`
**SHA256:** `{sha256}`
**SHA512:** `{sha512}`
""")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text.encode()
        
        md5 = hashlib.md5(text).hexdigest()
        sha1 = hashlib.sha1(text).hexdigest()
        sha256 = hashlib.sha256(text).hexdigest()
        sha512 = hashlib.sha512(text).hexdigest()
        
        await message.reply(f"""
**🔐 Hash Values**
**MD5:** `{md5}`
**SHA1:** `{sha1}`
**SHA256:** `{sha256}`
**SHA512:** `{sha512}`
""")
    else:
        await message.reply("**Usage:** `.hash <text>`")

@Client.on_message(filters.command("base64", Config.CMD_PREFIX) & filters.me)
async def base64_command(client: Client, message: Message):
    if len(message.command) > 2:
        mode = message.command[1].lower()
        text = " ".join(message.command[2:]).encode()
        
        if mode == "encode":
            encoded = base64.b64encode(text).decode()
            await message.reply(f"**🔐 Base64 Encoded:**\n`{encoded}`")
        elif mode == "decode":
            try:
                decoded = base64.b64decode(text).decode()
                await message.reply(f"**🔓 Base64 Decoded:**\n`{decoded}`")
            except:
                await message.reply("**❌ Invalid Base64!**")
        else:
            await message.reply("**Usage:** `.base64 encode <text>` or `.base64 decode <base64>`")
    else:
        await message.reply("**Usage:** `.base64 encode <text>` or `.base64 decode <base64>`")

@Client.on_message(filters.command("binary", Config.CMD_PREFIX) & filters.me)
async def binary_command(client: Client, message: Message):
    if len(message.command) > 2:
        mode = message.command[1].lower()
        text = " ".join(message.command[2:])
        
        if mode == "encode":
            binary = ' '.join(format(ord(c), '08b') for c in text)
            await message.reply(f"**🔢 Binary Encoded:**\n`{binary}`")
        elif mode == "decode":
            try:
                binary_values = text.split()
                ascii_string = ''.join(chr(int(b, 2)) for b in binary_values)
                await message.reply(f"**🔢 Binary Decoded:**\n`{ascii_string}`")
            except:
                await message.reply("**❌ Invalid binary!**")
        else:
            await message.reply("**Usage:** `.binary encode <text>` or `.binary decode <binary>`")
    else:
        await message.reply("**Usage:** `.binary encode <text>` or `.binary decode <binary>`")

@Client.on_message(filters.command("rot13", Config.CMD_PREFIX) & filters.me)
async def rot13_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        rot13 = text.translate(str.maketrans(
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
            'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm'
        ))
        await message.reply(f"**🔄 ROT13:**\n`{rot13}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        rot13 = text.translate(str.maketrans(
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
            'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm'
        ))
        await message.reply(f"**🔄 ROT13:**\n`{rot13}`")
    else:
        await message.reply("**Usage:** `.rot13 <text>`")

@Client.on_message(filters.command("urlencode", Config.CMD_PREFIX) & filters.me)
async def urlencode_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        encoded = quote(text)
        await message.reply(f"**🔗 URL Encoded:**\n`{encoded}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        encoded = quote(text)
        await message.reply(f"**🔗 URL Encoded:**\n`{encoded}`")
    else:
        await message.reply("**Usage:** `.urlencode <text>`")

@Client.on_message(filters.command("urldecode", Config.CMD_PREFIX) & filters.me)
async def urldecode_command(client: Client, message: Message):
    if len(message.command) > 1:
        text = " ".join(message.command[1:])
        decoded = unquote(text)
        await message.reply(f"**🔗 URL Decoded:**\n`{decoded}`")
    elif message.reply_to_message and message.reply_to_message.text:
        text = message.reply_to_message.text
        decoded = unquote(text)
        await message.reply(f"**🔗 URL Decoded:**\n`{decoded}`")
    else:
        await message.reply("**Usage:** `.urldecode <url>`")

@Client.on_message(filters.command("regex", Config.CMD_PREFIX) & filters.me)
async def regex_command(client: Client, message: Message):
    if len(message.command) > 2:
        pattern = message.command[1]
        text = " ".join(message.command[2:])
        
        try:
            matches = re.findall(pattern, text)
            if matches:
                result = "\n".join(str(m) for m in matches)
                await message.reply(f"**🔍 Regex Matches:**\n`{result}`")
            else:
                await message.reply("**🔍 No matches found!**")
        except Exception as e:
            await message.reply(f"**❌ Regex Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.regex <pattern> <text>`")

@Client.on_message(filters.command("wrap", Config.CMD_PREFIX) & filters.me)
async def wrap_command(client: Client, message: Message):
    if len(message.command) > 2:
        try:
            width = int(message.command[1])
            text = " ".join(message.command[2:])
            wrapped = textwrap.fill(text, width=width)
            await message.reply(f"**📦 Wrapped ({width} chars):**\n`{wrapped}`")
        except:
            await message.reply("**❌ Invalid width!**")
    else:
        await message.reply("**Usage:** `.wrap <width> <text>`")

# More text commands: .trim, .lstrip, .rstrip, .center, .ljust, .rjust, .zfill, .expandtabs, .split, .join, .replace, .strip, .removeprefix, .removesuffix, .startswith, .endswith, .isalpha, .isdigit, .isalnum, .isspace, .isupper, .islower, .istitle, .isprintable, .isidentifier, .isdecimal, .isnumeric, .islower, .isupper, .casefold, .encode, .decode, .format, .format_map, .partition, .rpartition, .splitlines, .rsplit, .index, .rindex, .find, .rfind, .count, .translate, .maketrans
