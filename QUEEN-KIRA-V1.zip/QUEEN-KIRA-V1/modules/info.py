from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import requests
import datetime
import time
import os

@Client.on_message(filters.command("ip", Config.CMD_PREFIX) & filters.me)
async def ip_command(client: Client, message: Message):
    if len(message.command) > 1:
        ip = message.command[1]
        try:
            response = requests.get(f"http://ip-api.com/json/{ip}")
            data = response.json()
            
            if data['status'] == 'success':
                text = f"""
**🌐 IP Information**
**IP:** {data['query']}
**Country:** {data['country']}
**Region:** {data['regionName']}
**City:** {data['city']}
**ZIP:** {data['zip']}
**Lat/Lon:** {data['lat']}, {data['lon']}
**ISP:** {data['isp']}
**Organization:** {data['org']}
**AS:** {data['as']}
"""
            else:
                text = "**❌ Invalid IP address!**"
        except:
            text = "**❌ Error fetching IP information!**"
        
        await message.reply(text)
    else:
        await message.reply("**Usage:** `.ip <ip_address>`")

@Client.on_message(filters.command("domain", Config.CMD_PREFIX) & filters.me)
async def domain_command(client: Client, message: Message):
    if len(message.command) > 1:
        domain = message.command[1]
        try:
            response = requests.get(f"https://api.domainsdb.info/v1/domains/search?domain={domain}")
            data = response.json()
            
            if data.get('domains'):
                domain_info = data['domains'][0]
                text = f"""
**🌐 Domain Information**
**Domain:** {domain_info['domain']}
**Country:** {domain_info.get('country', 'N/A')}
**Create Date:** {domain_info.get('create_date', 'N/A')}
**Update Date:** {domain_info.get('update_date', 'N/A')}
**Expiry Date:** {domain_info.get('expiry_date', 'N/A')}
**Registrar:** {domain_info.get('registrar', 'N/A')}
**Nameservers:** {', '.join(domain_info.get('name_servers', ['N/A']))}
"""
            else:
                text = "**❌ Domain not found!**"
        except:
            text = "**❌ Error fetching domain information!**"
        
        await message.reply(text)
    else:
        await message.reply("**Usage:** `.domain <domain_name>`")

@Client.on_message(filters.command("phone", Config.CMD_PREFIX) & filters.me)
async def phone_command(client: Client, message: Message):
    if len(message.command) > 1:
        number = message.command[1]
        try:
            response = requests.get(f"https://api.veriphone.io/v2/verify?phone={number}")
            data = response.json()
            
            if data.get('phone_valid'):
                text = f"""
**📱 Phone Information**
**Number:** {data['phone']}
**International:** {data['phone_international']}
**Country:** {data['country']}
**Country Code:** {data['country_code']}
**Location:** {data.get('location', 'N/A')}
**Carrier:** {data.get('carrier', 'N/A')}
**Valid:** {data['phone_valid']}
"""
            else:
                text = "**❌ Invalid phone number!**"
        except:
            text = "**❌ Error fetching phone information!**"
        
        await message.reply(text)
    else:
        await message.reply("**Usage:** `.phone <phone_number>`")

@Client.on_message(filters.command("dns", Config.CMD_PREFIX) & filters.me)
async def dns_command(client: Client, message: Message):
    if len(message.command) > 1:
        domain = message.command[1]
        try:
            import socket
            ip = socket.gethostbyname(domain)
            await message.reply(f"**🌐 DNS Lookup**\n**Domain:** {domain}\n**IP Address:** `{ip}`")
        except:
            await message.reply("**❌ Could not resolve domain!**")
    else:
        await message.reply("**Usage:** `.dns <domain>`")

@Client.on_message(filters.command("headers", Config.CMD_PREFIX) & filters.me)
async def headers_command(client: Client, message: Message):
    if len(message.command) > 1:
        url = message.command[1]
        try:
            response = requests.get(url)
            headers = dict(response.headers)
            text = "**📋 HTTP Headers**\n\n"
            for key, value in headers.items():
                text += f"**{key}:** {value}\n"
            
            if len(text) > 4096:
                with open("headers.txt", "w") as f:
                    f.write(text)
                await message.reply_document("headers.txt")
                os.remove("headers.txt")
            else:
                await message.reply(text)
        except:
            await message.reply("**❌ Error fetching headers!**")
    else:
        await message.reply("**Usage:** `.headers <url>`")

@Client.on_message(filters.command("userinfo", Config.CMD_PREFIX) & filters.me)
async def userinfo_command(client: Client, message: Message):
    if message.reply_to_message:
        user = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try:
            user = await client.get_users(message.command[1])
        except:
            user = message.from_user
    else:
        user = message.from_user
    
    text = f"""
**👤 User Information**
**ID:** `{user.id}`
**Name:** {user.first_name} {user.last_name or ''}
**Username:** @{user.username if user.username else 'None'}
**DC ID:** {getattr(user, 'dc_id', 'N/A')}
**Is Bot:** {user.is_bot}
**Is Premium:** {getattr(user, 'is_premium', False)}
**Status:** {getattr(user, 'status', 'N/A')}
**Language:** {getattr(user, 'language_code', 'N/A')}
"""
    await message.reply(text)

@Client.on_message(filters.command("chatinfo", Config.CMD_PREFIX) & filters.me)
async def chatinfo_command(client: Client, message: Message):
    chat = message.chat
    
    try:
        members = await client.get_chat_members_count(chat.id)
    except:
        members = "N/A"
    
    text = f"""
**💬 Chat Information**
**ID:** `{chat.id}`
**Title:** {chat.title if chat.title else 'Private Chat'}
**Type:** {chat.type.name}
**Members:** {members}
**Username:** @{chat.username if chat.username else 'None'}
**Description:** {chat.description if chat.description else 'None'}
**DC ID:** {getattr(chat, 'dc_id', 'N/A')}
**Protected:** {getattr(chat, 'has_protected_content', False)}
"""
    await message.reply(text)

@Client.on_message(filters.command("forwardinfo", Config.CMD_PREFIX) & filters.me)
async def forwardinfo_command(client: Client, message: Message):
    if message.reply_to_message and message.reply_to_message.forward_from:
        fwd = message.reply_to_message.forward_from
        text = f"""
**↪️ Forwarded From**
**Name:** {fwd.first_name} {fwd.last_name or ''}
**Username:** @{fwd.username if fwd.username else 'None'}
**ID:** `{fwd.id}`
"""
        await message.reply(text)
    else:
        await message.reply("**❌ This message wasn't forwarded or has no forward info!**")

@Client.on_message(filters.command("msgid", Config.CMD_PREFIX) & filters.me)
async def msgid_command(client: Client, message: Message):
    if message.reply_to_message:
        msg_id = message.reply_to_message.id
        await message.reply(f"**📨 Message ID:** `{msg_id}`")
    else:
        await message.reply(f"**📨 Message ID:** `{message.id}`")
