from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import os
import sys
import subprocess
import shutil
import psutil
import platform
import time

@Client.on_message(filters.command("eval", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def eval_command(client: Client, message: Message):
    if len(message.command) > 1:
        code = " ".join(message.command[1:])
        
        try:
            result = eval(code)
            await message.reply(f"**📊 Eval Result:**\n```\n{result}\n```")
        except Exception as e:
            await message.reply(f"**❌ Error:**\n```\n{str(e)}\n```")
    else:
        await message.reply("**Usage:** `.eval <python_code>`")

@Client.on_message(filters.command("exec", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def exec_command(client: Client, message: Message):
    if len(message.command) > 1:
        code = " ".join(message.command[1:])
        
        try:
            exec_globals = {}
            exec(code, exec_globals)
            await message.reply(f"**✅ Code executed successfully!**")
        except Exception as e:
            await message.reply(f"**❌ Error:**\n```\n{str(e)}\n```")
    else:
        await message.reply("**Usage:** `.exec <python_code>`")

@Client.on_message(filters.command("bash", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def bash_command(client: Client, message: Message):
    if len(message.command) > 1:
        cmd = " ".join(message.command[1:])
        
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            output = result.stdout if result.stdout else result.stderr
            
            if len(output) > 4096:
                with open("bash_output.txt", "w") as f:
                    f.write(output)
                await message.reply_document("bash_output.txt", caption=f"**📎 Command:** `{cmd}`")
                os.remove("bash_output.txt")
            else:
                await message.reply(f"**📎 Command:** `{cmd}`\n```\n{output}\n```")
        except Exception as e:
            await message.reply(f"**❌ Error:**\n```\n{str(e)}\n```")
    else:
        await message.reply("**Usage:** `.bash <command>`")

@Client.on_message(filters.command("pip", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def pip_command(client: Client, message: Message):
    if len(message.command) > 1:
        cmd = " ".join(message.command[1:])
        
        try:
            result = subprocess.run(f"pip {cmd}", shell=True, capture_output=True, text=True)
            output = result.stdout if result.stdout else result.stderr
            
            if len(output) > 4096:
                with open("pip_output.txt", "w") as f:
                    f.write(output)
                await message.reply_document("pip_output.txt", caption=f"**📎 Pip:** `{cmd}`")
                os.remove("pip_output.txt")
            else:
                await message.reply(f"**📎 Pip Output:**\n```\n{output}\n```")
        except Exception as e:
            await message.reply(f"**❌ Error:**\n```\n{str(e)}\n```")
    else:
        await message.reply("**Usage:** `.pip install <package>`")

@Client.on_message(filters.command("restart", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def restart_command(client: Client, message: Message):
    await message.reply("**🔄 Restarting userbot...**")
    await client.stop()
    os.execl(sys.executable, sys.executable, "-m", "main")

@Client.on_message(filters.command("update", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def update_command(client: Client, message: Message):
    status = await message.reply("**🔄 Updating userbot...**")
    
    try:
        result = subprocess.run("git pull", shell=True, capture_output=True, text=True)
        
        if result.returncode == 0:
            await status.edit_text(f"**✅ Updated successfully!**\n```\n{result.stdout}\n```\n**🔄 Restarting...**")
            await client.stop()
            os.execl(sys.executable, sys.executable, "-m", "main")
        else:
            await status.edit_text(f"**❌ Update failed!**\n```\n{result.stderr}\n```")
    except Exception as e:
        await status.edit_text(f"**❌ Error:** {str(e)}")

@Client.on_message(filters.command("logs", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def logs_command(client: Client, message: Message):
    try:
        with open("logs.txt", "r") as f:
            logs = f.read()[-3500:]
        
        await message.reply(f"**📋 Recent Logs:**\n```\n{logs}\n```")
    except:
        await message.reply("**❌ No logs found!**")

@Client.on_message(filters.command("clearlogs", Config.CMD_PREFIX) & filters.user(Config.SUDO_USERS))
async def clearlogs_command(client: Client, message: Message):
    try:
        open("logs.txt", "w").close()
        await message.reply("**✅ Logs cleared!**")
    except:
        await message.reply("**❌ Error clearing logs!**")

@Client.on_message(filters.command("sysinfo", Config.CMD_PREFIX) & filters.me)
async def sysinfo_command(client: Client, message: Message):
    boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
    now = datetime.datetime.now()
    uptime = now - boot_time
    
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    text = f"""
**🖥️ System Information**
**OS:** {platform.system()} {platform.release()}
**Arch:** {platform.machine()}
**Python:** {platform.python_version()}
**Uptime:** {uptime.days}d {uptime.seconds//3600}h {(uptime.seconds//60)%60}m

**⚡ CPU:**
**Usage:** {cpu_percent}%
**Cores:** {psutil.cpu_count()} physical, {psutil.cpu_count(logical=True)} logical

**💾 Memory:**
**Total:** {memory.total / (1024**3):.2f} GB
**Used:** {memory.used / (1024**3):.2f} GB
**Free:** {memory.available / (1024**3):.2f} GB
**Usage:** {memory.percent}%

**💽 Disk:**
**Total:** {disk.total / (1024**3):.2f} GB
**Used:** {disk.used / (1024**3):.2f} GB
**Free:** {disk.free / (1024**3):.2f} GB
**Usage:** {disk.percent}%
"""
    await message.reply(text)

@Client.on_message(filters.command("load", Config.CMD_PREFIX) & filters.me)
async def load_command(client: Client, message: Message):
    cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
    load_avg = psutil.getloadavg()
    
    text = f"**📊 System Load**\n\n"
    text += f"**Load Average:** {load_avg[0]:.2f}, {load_avg[1]:.2f}, {load_avg[2]:.2f}\n\n"
    
    for i, cpu in enumerate(cpu_percent):
        bar = "█" * int(cpu / 10) + "░" * (10 - int(cpu / 10))
        text += f"**CPU {i+1}:** [{bar}] {cpu}%\n"
    
    await message.reply(text)

@Client.on_message(filters.command("tasks", Config.CMD_PREFIX) & filters.me)
async def tasks_command(client: Client, message: Message):
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            processes.append(proc.info)
        except:
            pass
    
    processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
    
    text = "**📋 Top 10 Processes**\n\n"
    for i, proc in enumerate(processes[:10]):
        text += f"{i+1}. **{proc['name']}** (PID: {proc['pid']})\n"
        text += f"   CPU: {proc['cpu_percent']:.1f}% | RAM: {proc['memory_percent']:.1f}%\n"
    
    await message.reply(text)

# More developer commands: .kill, .pkill, .run, .shell, .git, .docker, .dockercompose, .kubectl, .terraform, .ansible, .jenkins, .github, .gitlab, .bitbucket, .heroku, .aws, .gcp, .azure, .digitalocean, .linode, .vultr, .hetzner, .ovh, .scaleway, .cloudflare, .nginx, .apache, .mysql, .postgres, .mongodb, .redis, .elastic, .kafka, .rabbitmq
