from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import requests
import random
import datetime

@Client.on_message(filters.command("anime", Config.CMD_PREFIX) & filters.me)
async def anime_command(client: Client, message: Message):
    if len(message.command) > 1:
        query = " ".join(message.command[1:])
        
        try:
            response = requests.get(f"https://api.jikan.moe/v4/anime?q={query}&limit=1")
            data = response.json()
            
            if data['data']:
                anime = data['data'][0]
                text = f"""
**🎬 Anime Info: {anime['title']}**
**Title (Japanese):** {anime['title_japanese']}
**Type:** {anime['type']}
**Episodes:** {anime['episodes']}
**Status:** {anime['status']}
**Aired:** {anime['aired']['string']}
**Rating:** {anime['rating']}
**Score:** {anime['score']}/10
**Rank:** #{anime['rank']}
**Popularity:** #{anime['popularity']}
**Synopsis:** {anime['synopsis'][:500]}...
[More Info]({anime['url']})
"""
                if anime.get('images', {}).get('jpg', {}).get('image_url'):
                    await message.reply_photo(anime['images']['jpg']['image_url'], caption=text)
                else:
                    await message.reply(text)
            else:
                await message.reply("**❌ Anime not found!**")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.anime <anime_name>`")

@Client.on_message(filters.command("manga", Config.CMD_PREFIX) & filters.me)
async def manga_command(client: Client, message: Message):
    if len(message.command) > 1:
        query = " ".join(message.command[1:])
        
        try:
            response = requests.get(f"https://api.jikan.moe/v4/manga?q={query}&limit=1")
            data = response.json()
            
            if data['data']:
                manga = data['data'][0]
                text = f"""
**📚 Manga Info: {manga['title']}**
**Title (Japanese):** {manga['title_japanese']}
**Type:** {manga['type']}
**Chapters:** {manga['chapters']}
**Volumes:** {manga['volumes']}
**Status:** {manga['status']}
**Published:** {manga['published']['string']}
**Score:** {manga['score']}/10
**Rank:** #{manga['rank']}
**Popularity:** #{manga['popularity']}
**Synopsis:** {manga['synopsis'][:500]}...
[More Info]({manga['url']})
"""
                if manga.get('images', {}).get('jpg', {}).get('image_url'):
                    await message.reply_photo(manga['images']['jpg']['image_url'], caption=text)
                else:
                    await message.reply(text)
            else:
                await message.reply("**❌ Manga not found!**")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.manga <manga_name>`")

@Client.on_message(filters.command("character", Config.CMD_PREFIX) & filters.me)
async def character_command(client: Client, message: Message):
    if len(message.command) > 1:
        query = " ".join(message.command[1:])
        
        try:
            response = requests.get(f"https://api.jikan.moe/v4/characters?q={query}&limit=1")
            data = response.json()
            
            if data['data']:
                char = data['data'][0]
                text = f"""
**👤 Character: {char['name']}**
**Name (Kanji):** {char['name_kanji']}
**Nicknames:** {', '.join(char['nicknames']) if char['nicknames'] else 'None'}
**Favorites:** {char['favorites']}
**About:** {char['about'][:500]}...
[More Info]({char['url']})
"""
                if char.get('images', {}).get('jpg', {}).get('image_url'):
                    await message.reply_photo(char['images']['jpg']['image_url'], caption=text)
                else:
                    await message.reply(text)
            else:
                await message.reply("**❌ Character not found!**")
        except Exception as e:
            await message.reply(f"**❌ Error:** {str(e)}")
    else:
        await message.reply("**Usage:** `.character <character_name>`")

@Client.on_message(filters.command("waifu", Config.CMD_PREFIX) & filters.me)
async def waifu_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.waifu.im/search")
        data = response.json()
        
        if data.get('images'):
            img = data['images'][0]
            await message.reply_photo(
                img['url'],
                caption=f"**🌸 Random Waifu**\n**Source:** {img.get('source', 'Unknown')}"
            )
        else:
            await message.reply("**❌ Could not fetch waifu!**")
    except:
        await message.reply("**❌ Error fetching waifu!**")

@Client.on_message(filters.command("neko", Config.CMD_PREFIX) & filters.me)
async def neko_command(client: Client, message: Message):
    try:
        response = requests.get("https://nekos.best/api/v2/neko")
        data = response.json()
        
        if data.get('results'):
            neko = data['results'][0]
            await message.reply_photo(
                neko['url'],
                caption=f"**🐱 Neko!**\n**Artist:** {neko.get('artist_name', 'Unknown')}"
            )
    except:
        await message.reply("**❌ Error fetching neko!**")

@Client.on_message(filters.command("topanime", Config.CMD_PREFIX) & filters.me)
async def topanime_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.jikan.moe/v4/top/anime")
        data = response.json()
        
        text = "**🏆 Top 10 Anime**\n\n"
        for i, anime in enumerate(data['data'][:10], 1):
            text += f"{i}. {anime['title']} - {anime['score']}/10\n"
        
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching top anime!**")

@Client.on_message(filters.command("topmanga", Config.CMD_PREFIX) & filters.me)
async def topmanga_command(client: Client, message: Message):
    try:
        response = requests.get("https://api.jikan.moe/v4/top/manga")
        data = response.json()
        
        text = "**🏆 Top 10 Manga**\n\n"
        for i, manga in enumerate(data['data'][:10], 1):
            text += f"{i}. {manga['title']} - {manga['score']}/10\n"
        
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching top manga!**")

@Client.on_message(filters.command("season", Config.CMD_PREFIX) & filters.me)
async def season_command(client: Client, message: Message):
    now = datetime.datetime.now()
    year = now.year
    month = now.month
    
    if month in [12, 1, 2]:
        season = "winter"
    elif month in [3, 4, 5]:
        season = "spring"
    elif month in [6, 7, 8]:
        season = "summer"
    else:
        season = "fall"
    
    try:
        response = requests.get(f"https://api.jikan.moe/v4/seasons/{year}/{season}")
        data = response.json()
        
        text = f"**🍂 {season.capitalize()} {year} Anime**\n\n"
        for i, anime in enumerate(data['data'][:10], 1):
            text += f"{i}. {anime['title']}\n"
        
        await message.reply(text)
    except:
        await message.reply("**❌ Error fetching seasonal anime!**")

# More anime commands: .animesearch, .mangasearch, .charactersearch, .randomanime, .randommanga, .randomcharacter, .animenews, .manganews, .animerecommend, .mangarecommend, .animestudio, .mangaauthor, .animereviews, .mangareviews, .animeschedule, .animetoday, .animethisweek, .animethismonth, .animegenres, .mangagenres, .animeyear, .mangayear, .animerating, .mangarating, .waifu, .husbando, .animegif, .mangapanel
