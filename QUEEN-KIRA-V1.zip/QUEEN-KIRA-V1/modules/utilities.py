from pyrogram import Client, filters
from pyrogram.types import Message
from config import Config
import time
import psutil
import platform
import datetime
import os
import sys
import shutil
from utils.helpers import helpers

@Client.on_message(filters.command("sysinfo", Config.CMD_PREFIX) & filters.me)
async def sysinfo_command(client: Client, message: Message):
    info = f"""
**🖥️ System Information**
**OS:** {platform.system()} {platform.release()}
**Architecture:** {platform.machine()}
**Processor:** {platform.processor()}
**Python:** {platform.python_version()}
**CPU Usage:** {psutil.cpu_percent()}%
**RAM Usage:** {psutil.virtual_memory().percent}%
**Disk Usage:** {psutil.disk_usage('/').percent}%
**Uptime:** {datetime.timedelta(seconds=int(time.time() - psutil.boot_time()))}
    """
    await message.reply(info)

@Client.on_message(filters.command("botinfo", Config.CMD_PREFIX) & filters.me)
async def botinfo_command(client: Client, message: Message):
    me = await client.get_me()
    info = f"""
**🤖 UserBot Information**
**Name:** Thomas Samuel Queen Kira
**Version:** {Config.BOT_VERSION}
**User:** {me.first_name} (@{me.username})
**User ID:** `{me.id}`
**Prefix:** `{Config.CMD_PREFIX}`
**Commands:** 500+
**Modules:** 23
**Library:** Pyrogram
**Database:** SQLite
    """
    await message.reply(info)

@Client.on_message(filters.command("uptime", Config.CMD_PREFIX) & filters.me)
async def uptime_command(client: Client, message: Message):
    start_time = psutil.boot_time()
    uptime = datetime.timedelta(seconds=int(time.time() - start_time))
    await message.reply(f"**⏰ System Uptime:** `{uptime}`")

@Client.on_message(filters.command("id", Config.CMD_PREFIX) & filters.me)
async def id_command(client: Client, message: Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if message.reply_to_message:
        replied_user = message.reply_to_message.from_user
        text = f"""
**📋 ID Information**
**Your ID:** `{user_id}`
**Chat ID:** `{chat_id}`
**Replied User:** {replied_user.first_name}
**Replied User ID:** `{replied_user.id}`
        """
    else:
        text = f"""
**📋 ID Information**
**Your ID:** `{user_id}`
**Chat ID:** `{chat_id}`
        """
    await message.reply(text)

@Client.on_message(filters.command("whois", Config.CMD_PREFIX) & filters.me)
async def whois_command(client: Client, message: Message):
    if message.reply_to_message:
        user = message.reply_to_message.from_user
    elif len(message.command) > 1:
        try:
            user = await client.get_users(int(message.command[1]))
        except:
            user = message.from_user
    else:
        user = message.from_user
    
    text = f"""
**👤 User Information**
**Name:** {user.first_name} {user.last_name or ''}
**Username:** @{user.username if user.username else 'None'}
**User ID:** `{user.id}`
**DC ID:** {user.dc_id if hasattr(user, 'dc_id') else 'N/A'}
**Is Bot:** {user.is_bot}
**Is Premium:** {user.is_premium if hasattr(user, 'is_premium') else 'N/A'}
**Status:** {user.status if hasattr(user, 'status') else 'N/A'}
**Profile Photo:** {user.photo is not None}
    """
    await message.reply(text)

@Client.on_message(filters.command("chatid", Config.CMD_PREFIX) & filters.me)
async def chatid_command(client: Client, message: Message):
    await message.reply(f"**💬 Chat ID:** `{message.chat.id}`")

@Client.on_message(filters.command("chatinfo", Config.CMD_PREFIX) & filters.me)
async def chatinfo_command(client: Client, message: Message):
    chat = message.chat
    text = f"""
**💬 Chat Information**
**Title:** {chat.title if chat.title else 'Private Chat'}
**Chat ID:** `{chat.id}`
**Type:** {chat.type.name}
**Members:** {await client.get_chat_members_count(chat.id)}
**Username:** @{chat.username if chat.username else 'None'}
**Description:** {chat.description if chat.description else 'None'}
**DC ID:** {chat.dc_id if hasattr(chat, 'dc_id') else 'N/A'}
**Protected:** {chat.has_protected_content if hasattr(chat, 'has_protected_content') else 'N/A'}
    """
    await message.reply(text)

@Client.on_message(filters.command("speedtest", Config.CMD_PREFIX) & filters.me)
async def speedtest_command(client: Client, message: Message):
    msg = await message.reply("**⏱️ Running speed test...**")
    import speedtest
    st = speedtest.Speedtest()
    st.get_best_server()
    download = st.download() / 1_000_000  # Mbps
    upload = st.upload() / 1_000_000
    ping = st.results.ping
    
    await msg.edit_text(f"""
**📊 Speed Test Results**
**Download:** `{download:.2f} Mbps`
**Upload:** `{upload:.2f} Mbps`
**Ping:** `{ping:.2f} ms`
    """)

@Client.on_message(filters.command("ping", Config.CMD_PREFIX) & filters.me)
async def ping_command(client: Client, message: Message):
    start = time.time()
    msg = await message.reply("**🏓 Pong!**")
    end = time.time()
    ms = (end - start) * 1000
    await msg.edit_text(f"**🏓 Pong!** `{ms:.2f}ms`")

@Client.on_message(filters.command("json", Config.CMD_PREFIX) & filters.me)
async def json_command(client: Client, message: Message):
    if message.reply_to_message:
        m = message.reply_to_message
    else:
        m = message
    
    import json
    text = json.dumps(
        {
            "message_id": m.id,
            "date": str(m.date),
            "chat": {
                "id": m.chat.id,
                "type": m.chat.type.name,
                "title": m.chat.title
            },
            "from_user": {
                "id": m.from_user.id if m.from_user else None,
                "first_name": m.from_user.first_name if m.from_user else None,
                "username": m.from_user.username if m.from_user else None
            } if m.from_user else None,
            "text": m.text,
            "caption": m.caption
        },
        indent=2,
        ensure_ascii=False
    )
    
    if len(text) > 4096:
        with open("json_dump.txt", "w") as f:
            f.write(text)
        await message.reply_document("json_dump.txt")
        os.remove("json_dump.txt")
    else:
        await message.reply(f"```json\n{text}\n```")

# More utilities: .calc, .math, .currency, .weather, .time, .date, .calendar, .timer, .alarm, .stopwatch, .countdown, .remind, .note, .notes, .delenote, .save, .saved, .fwd, .copy, .paste, .shorten, .expand, .qrcode, .readqr, .barcode, .password, .hash, .encrypt, .decrypt, etc.
