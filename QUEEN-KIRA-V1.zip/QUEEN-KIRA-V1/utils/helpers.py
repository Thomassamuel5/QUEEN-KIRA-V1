import time
import asyncio
import random
import string
from datetime import datetime
from pyrogram.types import Message
from config import Config

class Helpers:
    @staticmethod
    def get_readable_time(seconds: int) -> str:
        count = 0
        time_list = []
        time_suffix_list = ["s", "m", "h", "d", "w", "m", "y"]
        while count < 4:
            count += 1
            if count < 3:
                remainder, result = divmod(seconds, 60)
            else:
                if count == 3:
                    remainder, result = divmod(seconds, 24)
                elif count == 4:
                    remainder, result = divmod(seconds, 7)
            if seconds == 0 and remainder == 0:
                break
            time_list.append(int(result))
            seconds = int(remainder)
        for x in range(len(time_list)):
            time_list[x] = str(time_list[x]) + time_suffix_list[x]
        if len(time_list) == 4:
            time_list.pop(3)
        time_list.reverse()
        if len(time_list) == 1:
            time_list.insert(0, "0")
        return ":".join(time_list)
    
    @staticmethod
    def extract_user(message: Message) -> tuple:
        user_id = None
        user_name = None
        
        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            user_name = message.reply_to_message.from_user.first_name
        elif len(message.command) > 1:
            try:
                user_id = int(message.command[1])
            except:
                user_name = message.command[1]
        
        return user_id, user_name
    
    @staticmethod
    def random_string(length=10):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    
    @staticmethod
    def format_number(num):
        if num > 999999999:
            return f"{round(num / 1000000000, 2)}B"
        elif num > 999999:
            return f"{round(num / 1000000, 2)}M"
        elif num > 999:
            return f"{round(num / 1000, 2)}K"
        else:
            return str(num)

helpers = Helpers()
