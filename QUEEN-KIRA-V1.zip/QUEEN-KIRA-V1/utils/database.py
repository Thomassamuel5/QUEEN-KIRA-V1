import sqlite3
import json
from datetime import datetime

class Database:
    def __init__(self, db_path="tsqk.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                first_name TEXT,
                last_name TEXT,
                username TEXT,
                joined_date TEXT,
                is_sudo BOOLEAN DEFAULT 0
            )
        """)
        
        # Notes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                note_name TEXT,
                note_content TEXT,
                created_at TEXT
            )
        """)
        
        # Filters table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS filters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER,
                filter_name TEXT,
                filter_content TEXT
            )
        """)
        
        # Greetings table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS greetings (
                chat_id INTEGER PRIMARY KEY,
                welcome_msg TEXT,
                goodbye_msg TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def add_user(self, user_id, first_name, last_name, username):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO users (user_id, first_name, last_name, username, joined_date) VALUES (?, ?, ?, ?, ?)",
            (user_id, first_name, last_name, username, datetime.now().isoformat())
        )
        conn.commit()
        conn.close()
    
    def get_user(self, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()
        return user
    
    def add_note(self, user_id, note_name, note_content):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO notes (user_id, note_name, note_content, created_at) VALUES (?, ?, ?, ?)",
            (user_id, note_name, note_content, datetime.now().isoformat())
        )
        conn.commit()
        conn.close()
    
    def get_notes(self, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT note_name, note_content FROM notes WHERE user_id = ?", (user_id,))
        notes = cursor.fetchall()
        conn.close()
        return notes
    
    def delete_note(self, user_id, note_name):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM notes WHERE user_id = ? AND note_name = ?", (user_id, note_name))
        conn.commit()
        conn.close()

db = Database()
